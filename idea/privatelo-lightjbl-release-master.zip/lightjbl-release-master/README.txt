Lightweight JetBrains License Server v0.2.1
Binary Release (build 170516)

MD5 Checksum:
  lightjbl-ar71xx.ipk (OpenWRT package):
    2334409eddd3606061b8f6be4ef601bb
  lightjbl-linux-32:
    e4e82d968df21c2b7d67718712fa1b5d
  lightjbl-linux-64:
    4cad4fd8acdc2adc52c4821585d5f9a8
  lightjbl-linux-arm:
    c6010700071772a43d1761f30293238d
  lightjbl-macos:
    b79cd33532c179af6257b8d91f051373
  lightjbl-openwrt-ar71xx:
    49c8ab57419f6174506cdcb541c4037a
  lightjbl-win32.exe:
    10367375b2bf77f8d0846a49f9f7ca9f
  lightjbl-win64.exe:
    afc979e254f4742fa2661ab9d94740d9
