package com.zjg.model;

import com.zjg.util.RelativeInfo;

public class ExpendRecord {

	// �洢�ֶ���Ϣ
	private int id;
	private String addDate = null;
	//�û����ѡ��ص�����
	private int addTypeIndex;
	//�Ƚ�֮�󷵻ص�����
	private int addTypeReturnIndex;
	private String expe_gene_type;
	private String expe_detail_type;
	private double addNum;
	private String expeRemark = null;
	
	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAddDate() {
		return addDate;
	}

	public void setAddDate(String addDate) {
		this.addDate = addDate;
	}

	public int getAddTypeIndex() {
		return addTypeIndex;
	}

	public void setAddTypeIndex(int addTypeIndex) {
		this.addTypeIndex = addTypeIndex;
	}

	public int getAddTypeReturnIndex() {
		return addTypeReturnIndex;
	}

	/*
	 * ���ô˷���ǰ�����ȵ���setAddTypeIndex(int addTypeIndex)
	 */
	public void setAddTypeReturnIndex(int addTypeReturnIndex) {
		if(getAddTypeIndex()==addTypeReturnIndex){
			this.setexpe_gene_type(  RelativeInfo.expeAllType.get(addTypeReturnIndex).trim() );
			this.setexpe_detail_type(null);
		}else{
		    this.setexpe_gene_type(  RelativeInfo.expeAllType.get(addTypeReturnIndex).trim()  );
		    this.setexpe_detail_type(  RelativeInfo.expeAllType.get(getAddTypeIndex()).trim()  );
			
		}
		this.addTypeReturnIndex = addTypeReturnIndex;
	}

	
	public String getexpe_gene_type() {
		return expe_gene_type;
	}

	public void setexpe_gene_type(String expe_gene_type) {
		this.expe_gene_type = expe_gene_type;
	}

	public String getexpe_detail_type() {
		return expe_detail_type;
	}

	public void setexpe_detail_type(String expe_detail_type) {
		this.expe_detail_type = expe_detail_type;
	}

	public double getAddNum() {
		return addNum;
	}

	public void setAddNum(double addNum) {
		this.addNum = addNum;
	}

	public String getExpeRemark() {
		return expeRemark;
	}

	public void setExpeRemark(String expeRemark) {
		this.expeRemark = expeRemark;
	}

}
