package com.zjg.model;

import com.zjg.util.RelativeInfo;

public class ReceiptsRecord {

	// �洢�ֶ���Ϣ
	private int id;
	private String addDate = null;
	//�û����ѡ��ص�����
	private int addTypeIndex;
	//�Ƚ�֮�󷵻ص�����
	private int addTypeReturnIndex;
	private String rec_gene_type;
	private String rec_detail_type;
	private double addNum;
	private String receRemark = null;
	
	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAddDate() {
		return addDate;
	}

	public void setAddDate(String addDate) {
		this.addDate = addDate;
	}

	public int getAddTypeIndex() {
		return addTypeIndex;
	}

	public void setAddTypeIndex(int addTypeIndex) {
		this.addTypeIndex = addTypeIndex;
	}

	public int getAddTypeReturnIndex() {
		return addTypeReturnIndex;
	}

	/*
	 * ���ô˷���ǰ�����ȵ���setAddTypeIndex(int addTypeIndex)
	 */
	public void setAddTypeReturnIndex(int addTypeReturnIndex) {
		if(getAddTypeIndex()==addTypeReturnIndex){
			this.setRec_gene_type(  RelativeInfo.receAllType.get(addTypeReturnIndex).trim() );
			this.setRec_detail_type(null);
		}else{
		    this.setRec_gene_type(  RelativeInfo.receAllType.get(addTypeReturnIndex).trim()  );
		    this.setRec_detail_type(  RelativeInfo.receAllType.get(getAddTypeIndex()).trim()  );
			
		}
		this.addTypeReturnIndex = addTypeReturnIndex;
	}

	
	public String getRec_gene_type() {
		return rec_gene_type;
	}

	public void setRec_gene_type(String rec_gene_type) {
		this.rec_gene_type = rec_gene_type;
	}

	public String getRec_detail_type() {
		return rec_detail_type;
	}

	public void setRec_detail_type(String rec_detail_type) {
		this.rec_detail_type = rec_detail_type;
	}

	public double getAddNum() {
		return addNum;
	}

	public void setAddNum(double addNum) {
		this.addNum = addNum;
	}

	public String getReceRemark() {
		return receRemark;
	}

	public void setReceRemark(String receRemark) {
		this.receRemark = receRemark;
	}
}
