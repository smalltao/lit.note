package com.zjg.model;

public class LendRecord {
	private int id;
	private boolean lendOrBorrow; // true��ʾ�����false��ʾ����
	private String lendWho;
	private String lendDate;
	private double lendNum;
	private double hasRefundedNum;
	private String lendRemark;
	private boolean hasRefunded;

	public String getLendDate() {
		return lendDate;
	}

	public void setLendDate(String lendDate) {
		this.lendDate = lendDate;
	}

	public boolean isLendOrBorrow() {
		return lendOrBorrow;
	}

	public void setLendOrBorrow(boolean lendOrBorrow) {
		this.lendOrBorrow = lendOrBorrow;
	}

	public String getLendWho() {
		return lendWho;
	}

	public void setLendWho(String lendWho) {
		this.lendWho = lendWho;
	}

	public Double getLendNum() {
		return lendNum;
	}

	public void setLendNum(Double lendNum) {
		this.lendNum = lendNum;
	}

	public String getLendRemark() {
		return lendRemark;
	}

	public void setLendRemark(String lendRemark) {
		this.lendRemark = lendRemark;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public double getHasRefundedNum() {
		return hasRefundedNum;
	}

	public void setHasRefundedNum(double hasRefundedNum) {
		this.hasRefundedNum = hasRefundedNum;
	}

	public boolean isHasRefunded() {
		return hasRefunded;
	}

	public void setHasRefunded(boolean hasRefunded) {
		this.hasRefunded = hasRefunded;
	}

	public void setLendNum(double lendNum) {
		this.lendNum = lendNum;
	}

}
