package com.zjg.db;

import java.io.File;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;


/**
 * Description: project start date 2014/2/17<br/>
 * Date:2014/2/25
 * 
 * @author zhaoJianGuo 1527370012@qq.com
 * @version 1.0
 */
public class ManagerDB {

    private final static String SDCARD_PATH=File.separator+"mnt"+File.separator+"sdcard";
    private final static String DB_PATH=File.separator+"accountBook";
	private final static String DB_NAME = "account_book.db3";
	private final static int DB_VERSION = 1;

	//������ݿ������
	public static MyDatabaseHelper getDBHelper(Context context) {
		File sdCardPath=new File(SDCARD_PATH);
		//�ж��Ƿ����SDCARD
		if(sdCardPath.exists()){
			File appDBPath=new File(SDCARD_PATH+DB_PATH);
			//�ļ�Ŀ¼������
			if(!appDBPath.exists()){
				if(appDBPath.mkdirs()){
					
					return new MyDatabaseHelper(context, SDCARD_PATH+DB_PATH+File.separator+DB_NAME, DB_VERSION);
				}else{
					return new MyDatabaseHelper(context, DB_NAME, DB_VERSION);
				}
			//�ļ�Ŀ¼����	
			}else{
				return new MyDatabaseHelper(context, SDCARD_PATH+DB_PATH+File.separator+DB_NAME, DB_VERSION);
			}
		//������SDCARD�ļ�	
		}else{
			return new MyDatabaseHelper(context, DB_NAME, DB_VERSION);
		}
	}

	//������ݿ��һ������
	public static SQLiteDatabase getDBConn(MyDatabaseHelper myDatabaseHelper) {
		
		return myDatabaseHelper.getReadableDatabase();
	}

	//�ر����ݿ������
	public static void closeDBHelper(MyDatabaseHelper myDatabaseHelper) {
		if (myDatabaseHelper != null) {
			myDatabaseHelper.close();
		}
		if(myDatabaseHelper==null){
		}
	}
	
	//�ر����ݿ��һ������
	public static void closeDBConn(SQLiteDatabase dbConn){
		if(dbConn!=null){
			dbConn.close();
		}
	} 
}
