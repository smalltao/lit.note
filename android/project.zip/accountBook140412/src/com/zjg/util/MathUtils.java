package com.zjg.util;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class MathUtils {
   public static double formatDouble(double num){
		//����С�����λ��
		BigDecimal bigDeci = new BigDecimal(num);
		return bigDeci.setScale(2, RoundingMode.HALF_UP).doubleValue();
   }
   
   public static String formatDoubleOfString(String num){
		//����С�����λ��
		BigDecimal bigDeci = new BigDecimal(num);
		return Double.toString( bigDeci.setScale(2, RoundingMode.HALF_UP).doubleValue()  );
   }
}
