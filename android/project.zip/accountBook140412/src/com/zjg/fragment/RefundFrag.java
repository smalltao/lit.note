package com.zjg.fragment;

import java.util.Calendar;
import com.zjg.activity.R;
import com.zjg.db.ManagerDB;
import com.zjg.service.RefundService;
import com.zjg.util.RelativeInfo;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

/**
 * Description: <br/>
 * Date:2014/3/4
 * 
 * @author zhaoJianGuo 1527370012@qq.com
 * @version 1.0
 */
public class RefundFrag extends Fragment {
    private RefundService refundService=null;
	
	//�б�
	private ListView list = null;
	
	private EditText refundStartDate = null;
	private EditText refundEndDate = null;
	private ToggleButton toggleBtn=null;
	private TextView sumView = null;


	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		refundService=new RefundService(getActivity());
	}

	// ��д�÷������÷������ص�View����ΪFragment��ʾ�����
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.refund, container, false);
		
		toggleBtn=(ToggleButton)rootView.findViewById(R.id.refund_toggle_btn);
		sumView =(TextView)rootView.findViewById(R.id.refund_query_sum);

		// ��ѯ��ʼ�������Ӽ����¼�
		refundStartDate = (EditText) rootView
				.findViewById(R.id.refund_start_date);
		refundStartDate.setText(RelativeInfo.getMadeDate());
		refundStartDate
				.setOnClickListener(new android.view.View.OnClickListener() {

					@Override
					public void onClick(View v) {
						Calendar c = Calendar.getInstance();
						// ֱ�Ӵ���һ��DatePickerDialog�Ի���ʵ������������ʾ����
						new DatePickerDialog(
								getActivity(),
								// �󶨼�����
								new DatePickerDialog.OnDateSetListener() {
									@Override
									public void onDateSet(DatePicker dp,
											int year, int month, int dayOfMonth) {
										refundStartDate.setText( RelativeInfo.getFormatDate(year, month, dayOfMonth) );
									}
								}
								// ���ó�ʼ����
								, c.get(Calendar.YEAR), c.get(Calendar.MONTH),
								c.get(Calendar.DAY_OF_MONTH)).show();
					}
				});

		// ��ѯ�����������Ӽ����¼�
		refundEndDate = (EditText) rootView
				.findViewById(R.id.refund_end_date);
		refundEndDate.setText(RelativeInfo.getNowDate());
		refundEndDate
				.setOnClickListener(new android.view.View.OnClickListener() {

					@Override
					public void onClick(View v) {
						Calendar c = Calendar.getInstance();
						// ֱ�Ӵ���һ��DatePickerDialog�Ի���ʵ������������ʾ����
						new DatePickerDialog(
								getActivity(),
								// �󶨼�����
								new DatePickerDialog.OnDateSetListener() {
									@Override
									public void onDateSet(DatePicker dp,
											int year, int month, int dayOfMonth) {
										refundEndDate.setText( RelativeInfo.getFormatDate(year, month, dayOfMonth) );
									}
								}
								// ���ó�ʼ����
								, c.get(Calendar.YEAR), c.get(Calendar.MONTH),
								c.get(Calendar.DAY_OF_MONTH)).show();
					}
				});

		Button queryBtn=(Button)rootView.findViewById(R.id.refund_query);
		queryBtn.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				String startDateStr=refundStartDate.getText().toString().trim();
                String endDateStr=refundEndDate.getText().toString().trim();

                
                if(startDateStr.compareTo(endDateStr)>0){
                	Toast.makeText(getActivity(),getString(R.string.date_error) ,Toast.LENGTH_LONG).show();
                	
                	return ;
                }
				
				
				list.setAdapter( refundService.queryRefund( startDateStr
						, endDateStr
						, toggleBtn.isChecked() ) );

				sumView.setText("����:"
						+ String.valueOf(refundService.getAccountSum()) + "Ԫ");				
			}
		});

		list = (ListView) rootView
				.findViewById(R.id.refund_simpleListView);

		list.setAdapter( refundService.queryRefund( 
				refundStartDate.getText().toString(),
				refundEndDate.getText().toString(), toggleBtn.isChecked() ) );
		sumView.setText("����:"
				+ String.valueOf(refundService.getAccountSum()) + "Ԫ");	
		


		return rootView;
	}
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		ManagerDB.closeDBHelper(refundService.getDbHelper());
	}
}
