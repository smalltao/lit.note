package com.zjg.fragment;

import java.util.Calendar;
import java.util.Map;

import com.zjg.activity.R;
import com.zjg.db.ManagerDB;
import com.zjg.model.LendRecord;
import com.zjg.service.LendService;
import com.zjg.util.RelativeInfo;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ToggleButton;

/**
 * Description: <br/>
 * Date:2014/3/4
 * 
 * @author zhaoJianGuo 1527370012@qq.com
 * @version 1.0
 */
public class LendFrag extends Fragment {
	// Ϊ�Ի��������
	static Activity myActivity;
	private LendService lendService = null;
	private LendRecord lendRecord = null;

	// �б�
	private ListView list = null;

	private EditText lendDate = null;
	private EditText lendWho = null;
	private EditText lendNum = null;
	private EditText lendRemark = null;
	private ToggleButton lendToggleBtn = null;
	private EditText lendQueryStartDate = null;
	private EditText lendQueryEndDate = null;
	private ToggleButton querytoggleBtn = null;
	private TextView sumView = null;

	private TextView alertText1 = null;
	private TextView alertText2 = null;

	private static AlertDialog builder;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		myActivity = getActivity();

		lendService = new LendService(myActivity);

	}

	// ��д�÷������÷������ص�View����ΪFragment��ʾ�����
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.lend, container, false);

		lendWho = (EditText) rootView.findViewById(R.id.lend_who);
		lendNum = (EditText) rootView.findViewById(R.id.lend_num);
		lendRemark = (EditText) rootView.findViewById(R.id.lend_remark);
		lendToggleBtn = (ToggleButton) rootView
				.findViewById(R.id.lend_toggle_btn);
		querytoggleBtn = (ToggleButton) rootView
				.findViewById(R.id.lend_toggle_btn2);
		sumView = (TextView) rootView.findViewById(R.id.lend_query_sum);

		// �����������Ӽ����¼�
		lendDate = (EditText) rootView.findViewById(R.id.lend_date);
		lendDate.setText(RelativeInfo.getNowDate());
		lendDate.setOnClickListener(new android.view.View.OnClickListener() {

			@Override
			public void onClick(View v) {
				Calendar c = Calendar.getInstance();
				// ֱ�Ӵ���һ��DatePickerDialog�Ի���ʵ������������ʾ����
				new DatePickerDialog(getActivity(),
				// �󶨼�����
						new DatePickerDialog.OnDateSetListener() {
							@Override
							public void onDateSet(DatePicker dp, int year,
									int month, int dayOfMonth) {
								lendDate.setText(RelativeInfo.getFormatDate(
										year, month, dayOfMonth));
							}
						}
						// ���ó�ʼ����
						, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c
								.get(Calendar.DAY_OF_MONTH)).show();
			}
		});

		Button lendBtn = (Button) rootView.findViewById(R.id.lend_lend_btn);
		lendBtn.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				if (TextUtils.isEmpty(lendWho.getText().toString().trim())) {
					lendWho.setError(getString(R.string.comm_required));
					lendWho.requestFocus();
					return;
				}
				if (TextUtils.isEmpty(lendNum.getText().toString().trim())) {
					lendNum.setError(getString(R.string.comm_required));
					lendNum.requestFocus();
					return;
				}
				
				
				LendRecord lendRec = new LendRecord();
				lendRec.setLendDate(lendDate.getText().toString());
				lendRec.setLendOrBorrow(lendToggleBtn.isChecked());
				lendRec.setLendNum(Double.valueOf(lendNum.getText().toString()
						.trim()));
				lendRec.setLendWho(lendWho.getText().toString().trim());
				lendRec.setLendRemark(lendRemark.getText().toString().trim());

				// ���÷����������ݲ���
				if (lendService.addLend(lendRec) == true) {
					Toast.makeText(getActivity(), "��������¼�ɹ�", Toast.LENGTH_LONG)
							.show();
					lendToggleBtn.setChecked(true);
					lendWho.setText(null);
					lendNum.setText(null);
					lendRemark.setText(null);
				} else {
					Toast.makeText(getActivity(), "��������¼ʧ��", Toast.LENGTH_LONG)
							.show();
				}
			}
		});

		// ��ѯ��ʼ�������Ӽ����¼�
		lendQueryStartDate = (EditText) rootView
				.findViewById(R.id.lend_start_date);
		lendQueryStartDate.setText(RelativeInfo.getMadeDate());
		lendQueryStartDate
				.setOnClickListener(new android.view.View.OnClickListener() {

					@Override
					public void onClick(View v) {
						Calendar c = Calendar.getInstance();
						// ֱ�Ӵ���һ��DatePickerDialog�Ի���ʵ������������ʾ����
						new DatePickerDialog(
								getActivity(),
								// �󶨼�����
								new DatePickerDialog.OnDateSetListener() {
									@Override
									public void onDateSet(DatePicker dp,
											int year, int month, int dayOfMonth) {
										lendQueryStartDate.setText(RelativeInfo
												.getFormatDate(year, month,
														dayOfMonth));
									}
								}
								// ���ó�ʼ����
								, c.get(Calendar.YEAR), c.get(Calendar.MONTH),
								c.get(Calendar.DAY_OF_MONTH)).show();
					}
				});

		// ��ѯ�����������Ӽ����¼�
		lendQueryEndDate = (EditText) rootView.findViewById(R.id.lend_end_date);
		lendQueryEndDate.setText(RelativeInfo.getNowDate());
		lendQueryEndDate
				.setOnClickListener(new android.view.View.OnClickListener() {

					@Override
					public void onClick(View v) {
						Calendar c = Calendar.getInstance();
						// ֱ�Ӵ���һ��DatePickerDialog�Ի���ʵ������������ʾ����
						new DatePickerDialog(
								getActivity(),
								// �󶨼�����
								new DatePickerDialog.OnDateSetListener() {
									@Override
									public void onDateSet(DatePicker dp,
											int year, int month, int dayOfMonth) {
										lendQueryEndDate.setText(RelativeInfo
												.getFormatDate(year, month,
														dayOfMonth));
									}
								}
								// ���ó�ʼ����
								, c.get(Calendar.YEAR), c.get(Calendar.MONTH),
								c.get(Calendar.DAY_OF_MONTH)).show();
					}
				});

		// Ϊ��ѯ��ť�����¼�
		Button lendQueryBtn = (Button) rootView.findViewById(R.id.lend_query);
		lendQueryBtn.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				String startDateStr=lendQueryStartDate
						.getText().toString().trim();
                String endDateStr=lendQueryEndDate.getText()
						.toString().trim();

                
                if(startDateStr.compareTo(endDateStr)>0){
                	Toast.makeText(getActivity(),getString(R.string.date_error) ,Toast.LENGTH_LONG).show();
                	
                	return ;
                }
				
				list.setAdapter(lendService.queryLend(startDateStr,endDateStr , querytoggleBtn.isChecked()));

				sumView.setText("����:"
						+ String.valueOf(lendService.getAccountSum()) + "Ԫ");
			}
		});

		list = (ListView) rootView.findViewById(R.id.lend_simpleListView);
		// ΪListView����Adapter
		list.setAdapter(lendService.queryLend(lendQueryStartDate.getText()
				.toString(), lendQueryEndDate.getText().toString(),
				querytoggleBtn.isChecked()));
		sumView.setText("����:" + String.valueOf(lendService.getAccountSum())
				+ "Ԫ");

		final LinearLayout linerLayoutDialog = (LinearLayout) myActivity
				.getLayoutInflater().inflate(R.layout.refund_dialog, null);
		builder = new AlertDialog.Builder(myActivity)
		// ���öԻ����ͼ��
				.setIcon(R.drawable.smile)
				// ���öԻ���ı���
				.setTitle(R.string.refund_alert_title)
				// ���öԻ�����ʾ��View����
				.setView(linerLayoutDialog)
				// Ϊ�Ի�������һ����ȷ������ť
				.setPositiveButton(getString(R.string.dialog_config), new OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						EditText editText = (EditText) linerLayoutDialog
								.findViewById(R.id.refund_alert_count);
						double refundNumEdit = Double.valueOf(editText
								.getText().toString());
                        //�ж�����������Ƿ�Ϸ���ӦС�ڵ�����Ƿ���
						if(refundNumEdit==0){
							Toast.makeText(myActivity, "������Ӧ����0Ԫ!",
									Toast.LENGTH_LONG).show();
							editText.setText(null);
							return ;
						}
 						if (lendRecord.getLendNum() >= refundNumEdit
								+ lendRecord.getHasRefundedNum()) {

							if (lendService.refund(lendRecord, refundNumEdit)) {
								Toast.makeText(
										myActivity,
										"�ɹ�����" + editText.getText().toString()
												+ "Ԫ", Toast.LENGTH_LONG)
										.show();
								editText.setText(null);
							} else {
								Toast.makeText(myActivity, "����ʧ�ܣ�",
										Toast.LENGTH_LONG).show();
							}
						}else{
							Toast.makeText(myActivity, "���������ӦС�ڵ���"+(lendRecord.getLendNum()-lendRecord.getHasRefundedNum()),
									Toast.LENGTH_LONG).show();
						}

					}
				})
				// Ϊ�Ի�������һ����ȡ������ť
				.setNegativeButton(getString(R.string.dialog_cancel), new OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// ȡ�������κ����顣
					}
				})
				// �����Ի���
				.create();
		// ΪListView���б�����¼����¼�������
		list.setOnItemClickListener(new OnItemClickListener() {
			// ��position�����ʱ�����÷�����
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				@SuppressWarnings("unchecked")
				Map<String, Object> listItem = (Map<String, Object>) list
						.getAdapter().getItem(position);

				// ��ѯ����ǰ��¼����Ϣ
				lendRecord = lendService.queryById((Integer) listItem.get("id"));

				// ���öԻ����ϵ�������ʾ��Ϣ
				alertText1 = (TextView) linerLayoutDialog
						.findViewById(R.id.refund_dialog_des1);
				alertText1.setText(lendRecord.getLendDate()
						+ (lendRecord.isLendOrBorrow() ? "���" : "����")
						+ lendRecord.getLendWho() + lendRecord.getLendNum()
						+ "Ԫ��");
				alertText2 = (TextView) linerLayoutDialog
						.findViewById(R.id.refund_dialog_des2);
				alertText2.setText("�ѻ�"
						+ lendRecord.getHasRefundedNum()
						+ "Ԫ����Ƿ"
						+ (lendRecord.getLendNum() - lendRecord
								.getHasRefundedNum()) + "Ԫ��");

				builder.setView(linerLayoutDialog);
				builder.show();

			}
		});

		return rootView;
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		ManagerDB.closeDBHelper(lendService.getDbHelper());
	}
}
