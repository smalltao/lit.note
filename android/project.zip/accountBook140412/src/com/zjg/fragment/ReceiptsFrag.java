package com.zjg.fragment;

import java.util.Calendar;
import com.zjg.activity.R;
import com.zjg.db.ManagerDB;
import com.zjg.model.ReceiptsRecord;
import com.zjg.service.ReceiptsService;
import com.zjg.util.RelativeInfo;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Description: <br/>
 * Date:2014/3/1
 * 
 * @author zhaoJianGuo 1527370012@qq.com
 * @version 1.0
 */
public class ReceiptsFrag extends Fragment {

	private ReceiptsService receService = null;

	// �������������б���ʾ
	private String[] items = null;

	// �б�
	private ListView list = null;

	private EditText receDate = null;
	private EditText receType = null;
	private EditText receNum = null;
	private EditText receRemark = null;
	private EditText receTypeQuery = null;
	private EditText receDateQueryStart = null;
	private EditText receDateQueryEnd = null;
	private TextView sumView = null;

	// �����ж����������ѡ�����������
	private int receTypeTag = 1;
	private int addTypeIndex = 0;
	private int queryTypeIndex = 0;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// ʹ��RelativeInfo�е����ݳ�ʼ��items
		items = new String[RelativeInfo.receAllType.size()];
		items = RelativeInfo.receAllType.toArray(items);

		receService = new ReceiptsService(getActivity());
	}

	// ��д�÷������÷������ص�View����ΪFragment��ʾ�����
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.receipts, container, false);

		receNum = (EditText) rootView.findViewById(R.id.receipts_add_num);
		receRemark = (EditText) rootView.findViewById(R.id.receipts_remark);
		sumView = (TextView) rootView.findViewById(R.id.receipts_query_sum);

		// �����������Ӽ����¼�
		receDate = (EditText) rootView.findViewById(R.id.receipts_row1_edit1);
		receDate.setText(RelativeInfo.getNowDate());
		receDate.setOnClickListener(new android.view.View.OnClickListener() {

			@Override
			public void onClick(View v) {
				Calendar c = Calendar.getInstance();
				// ֱ�Ӵ���һ��DatePickerDialog�Ի���ʵ������������ʾ����
				new DatePickerDialog(getActivity(),
				// �󶨼�����
						new DatePickerDialog.OnDateSetListener() {
							@Override
							public void onDateSet(DatePicker dp, int year,
									int month, int dayOfMonth) {
								receDate.setText(RelativeInfo.getFormatDate(
										year, month, dayOfMonth));
							}
						}
						// ���ó�ʼ����
						, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c
								.get(Calendar.DAY_OF_MONTH)).show();
			}
		});

		// �������ͼ����¼�
		receType = (EditText) rootView.findViewById(R.id.receipts_row1_inType);
		receType.setText(items[0].toString().trim());
		receType.setOnClickListener(new android.view.View.OnClickListener() {

			@Override
			public void onClick(View v) {
				receTypeTag = 1;
				singleChoice(v);
			}
		});

		// ���Ӱ�ť�¼�
		Button addBtn = (Button) rootView.findViewById(R.id.receipts_add_btn);
		addBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				if(TextUtils.isEmpty( receNum.getText().toString()
						.trim() ) ){
					receNum.setError(getString(R.string.comm_required));
					receNum.requestFocus();
					return ;
					
				}
				
				ReceiptsRecord receReco = new ReceiptsRecord();
				receReco.setAddDate(receDate.getText().toString());
				receReco.setAddTypeIndex(addTypeIndex);
				receReco.setAddTypeReturnIndex(RelativeInfo.judgeTypeLevel(1,
						addTypeIndex));
				receReco.setAddNum(Double.valueOf(receNum.getText().toString()
						.trim()));
				receReco.setReceRemark(receRemark.getText().toString().trim());

				// ���÷����������ݲ���
				if (receService.addReceipts(receReco) == true) {
					Toast.makeText(getActivity(), "������¼�ɹ�", Toast.LENGTH_LONG)
							.show();
					receNum.setText(null);
					receRemark.setText(null);
				} else {
					Toast.makeText(getActivity(), "������¼ʧ��", Toast.LENGTH_LONG)
							.show();
				}

			}
		});

		// ��ѯ��ʼ�������Ӽ����¼�
		receDateQueryStart = (EditText) rootView
				.findViewById(R.id.receipts_row5_edit1);
		receDateQueryStart.setText(RelativeInfo.getMadeDate());
		receDateQueryStart
				.setOnClickListener(new android.view.View.OnClickListener() {

					@Override
					public void onClick(View v) {
						Calendar c = Calendar.getInstance();
						// ֱ�Ӵ���һ��DatePickerDialog�Ի���ʵ������������ʾ����
						new DatePickerDialog(
								getActivity(),
								// �󶨼�����
								new DatePickerDialog.OnDateSetListener() {
									@Override
									public void onDateSet(DatePicker dp,
											int year, int month, int dayOfMonth) {
										receDateQueryStart.setText(RelativeInfo
												.getFormatDate(year, month,
														dayOfMonth));
									}
								}
								// ���ó�ʼ����
								, c.get(Calendar.YEAR), c.get(Calendar.MONTH),
								c.get(Calendar.DAY_OF_MONTH)).show();
					}
				});

		// ��ѯ�����������Ӽ����¼�
		receDateQueryEnd = (EditText) rootView
				.findViewById(R.id.receipts_row5_edit2);
		receDateQueryEnd.setText(RelativeInfo.getNowDate());
		receDateQueryEnd
				.setOnClickListener(new android.view.View.OnClickListener() {

					@Override
					public void onClick(View v) {
						Calendar c = Calendar.getInstance();
						// ֱ�Ӵ���һ��DatePickerDialog�Ի���ʵ������������ʾ����
						new DatePickerDialog(
								getActivity(),
								// �󶨼�����
								new DatePickerDialog.OnDateSetListener() {
									@Override
									public void onDateSet(DatePicker dp,
											int year, int month, int dayOfMonth) {
										receDateQueryEnd.setText(RelativeInfo
												.getFormatDate(year, month,
														dayOfMonth));
									}
								}
								// ���ó�ʼ����
								, c.get(Calendar.YEAR), c.get(Calendar.MONTH),
								c.get(Calendar.DAY_OF_MONTH)).show();
					}
				});

		// ��ѯ�������Ӽ����¼�
		receTypeQuery = (EditText) rootView
				.findViewById(R.id.receipts_row6_edit1);
		receTypeQuery
				.setOnClickListener(new android.view.View.OnClickListener() {

					@Override
					public void onClick(View v) {
						receTypeTag = 2;
						singleChoice(v);
					}
				});
		
		// ��ѯ��ť�¼�
		Button queryBtn = (Button) rootView
				.findViewById(R.id.receipts_query_btn);
		queryBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
                String startDateStr=receDateQueryStart.getText().toString().trim();
                String endDateStr=receDateQueryEnd.getText().toString().trim();

                
                if(startDateStr.compareTo(endDateStr)>0){
                	Toast.makeText(getActivity(),getString(R.string.date_error) ,Toast.LENGTH_LONG).show();
                	
                	return ;
                }
                 
                int paramIndex=queryTypeIndex;
                //�жϲ�ѯ�������Ƿ�Ϊ��
                if("".equals( receTypeQuery.getText().toString().trim() )||
                		receTypeQuery.getText().toString()==null){
                	paramIndex=-1;
                }
				list.setAdapter( receService.queryReceipts(
						startDateStr,endDateStr
						, paramIndex) );

				sumView.setText("����:"
						+ String.valueOf(receService.getAccountSum()) + "Ԫ");
			}
		});
		
		
		

		list = (ListView) rootView.findViewById(R.id.receipts_simpleListView);
		// ΪListView����Adapter
		list.setAdapter( receService.queryReceipts(
				RelativeInfo.getMadeDate(),
				RelativeInfo.getNowDate(),-1)  );
		sumView.setText("����:"
				+ String.valueOf(receService.getAccountSum()) + "Ԫ");
		// ΪListView���б�����¼����¼�������
		list.setOnItemClickListener(new OnItemClickListener() {
			// ��position�����ʱ�����÷�����
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
			}
		});
		list.setOnItemSelectedListener(new OnItemSelectedListener() {
			// ��position�ѡ��ʱ�����÷�����
			@Override
			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
			}

			@Override
			public void onNothingSelected(AdapterView<?> parent) {
			}
		});

		return rootView;
	}

	// ��������ѡ��Ի���
	public void singleChoice(View source) {
		int parmIndex=0;
		switch (receTypeTag) {
		case 1:
			parmIndex=addTypeIndex;
			break;
		case 2:
			parmIndex=queryTypeIndex;
			break;
		default:
			break;
		}
		
		AlertDialog.Builder builder = new AlertDialog.Builder(getActivity())
		// ���öԻ������
				.setTitle(R.string.dialog_chose_rece)
				// ����ͼ��
				.setIcon(R.drawable.smile)
				// ���õ�ѡ�б���,Ĭ��ѡ�еڶ������Ϊ1��
				.setSingleChoiceItems(items, parmIndex, new OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						switch (receTypeTag) {
						case 1:
							addTypeIndex=which;
							break;
						case 2:
							queryTypeIndex=which;
							break;
						default:
							break;
						}
					}
				});
		// ΪAlertDialog.Builder���ӡ�ȷ������ť
		setPositiveButton(builder);
		// ΪAlertDialog.Builder���ӡ�ȡ������ť
		setNegativeButton(builder).create().show();
	}

	private AlertDialog.Builder setPositiveButton(AlertDialog.Builder builder) {
		// ����setPositiveButton��������ȷ����ť
		return builder.setPositiveButton(getString(R.string.dialog_config), new OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				// ���ܴ�����ȷ��which����
				switch (receTypeTag) {
				case 1:
					receType.setText(items[addTypeIndex].toString().trim());
					break;
				case 2:
					receTypeQuery.setText(items[queryTypeIndex].toString().trim());
					break;
				default:
					break;
				}

			}
		});
	}

	private AlertDialog.Builder setNegativeButton(AlertDialog.Builder builder) {
		// ����setNegativeButton��������ȡ����ť
		return builder.setNegativeButton(getString(R.string.dialog_cancel), new OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				// ���ܴ�����ȷ��which����
				switch (receTypeTag) {
				case 2:
					receTypeQuery.setText("");
					queryTypeIndex = 0;
					break;
				default:
					break;
				}
			}
		});
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		ManagerDB.closeDBHelper(receService.getDbHelper());
	}
}
