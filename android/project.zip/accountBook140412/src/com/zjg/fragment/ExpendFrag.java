package com.zjg.fragment;

import java.util.Calendar;
import com.zjg.activity.R;
import com.zjg.db.ManagerDB;
import com.zjg.model.ExpendRecord;
import com.zjg.service.ExpendService;
import com.zjg.util.RelativeInfo;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;

/**
 * Description: <br/>
 * Date:2014/3/3
 * 
 * @author zhaoJianGuo 1527370012@qq.com
 * @version 1.0
 */
public class ExpendFrag extends Fragment {

	private ExpendService expeService = null;

	// ����֧�������б���ʾ
	private String[] items = null;

	// �б�
	private ListView list = null;

	private EditText expeDate = null;
	private EditText expeType = null;
	private EditText expeNum = null;
	private EditText expeRemark = null;
	private EditText expeTypeQuery = null;
	private EditText expeDateQueryStart = null;
	private EditText expeDateQueryEnd = null;
	private TextView sumView = null;

	// �����ж����������ѡ�����������
	private int expeTypeTag = 1;
	private int addTypeIndex = 0;
	private int queryTypeIndex = 0;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// ʹ��RelativeInfo�е����ݳ�ʼ��items
		items = new String[RelativeInfo.expeAllType.size()];
		items = RelativeInfo.expeAllType.toArray(items);

		expeService = new ExpendService(getActivity());
	}

	// ��д�÷������÷������ص�View����ΪFragment��ʾ�����
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.expend, container, false);

		expeNum = (EditText) rootView.findViewById(R.id.expend_num);
		expeRemark = (EditText) rootView.findViewById(R.id.expend_remark);
		sumView = (TextView) rootView.findViewById(R.id.expend_query_sum);

		// �����������Ӽ����¼�
		expeDate = (EditText) rootView.findViewById(R.id.expend_date);
		expeDate.setText(RelativeInfo.getNowDate());
		expeDate.setOnClickListener(new android.view.View.OnClickListener() {

			@Override
			public void onClick(View v) {
				Calendar c = Calendar.getInstance();
				// ֱ�Ӵ���һ��DatePickerDialog�Ի���ʵ������������ʾ����
				new DatePickerDialog(getActivity(),
				// �󶨼�����
						new DatePickerDialog.OnDateSetListener() {
							@Override
							public void onDateSet(DatePicker dp, int year,
									int month, int dayOfMonth) {
								expeDate.setText(RelativeInfo.getFormatDate(
										year, month, dayOfMonth));
							}
						}
						// ���ó�ʼ����
						, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c
								.get(Calendar.DAY_OF_MONTH)).show();
			}
		});

		// �������ͼ����¼�
		expeType = (EditText) rootView.findViewById(R.id.expend__out_type);
		expeType.setText(items[0].toString().trim());
		expeType.setOnClickListener(new android.view.View.OnClickListener() {

			@Override
			public void onClick(View v) {
				expeTypeTag = 1;
				singleChoice(v);
			}
		});

		// ���Ӱ�ť�¼�
		Button addBtn = (Button) rootView.findViewById(R.id.expend_add_btn);
		addBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				if (TextUtils.isEmpty(expeNum.getText().toString().trim())) {
					expeNum.setError(getString(R.string.comm_required));
					expeNum.requestFocus();
					return;

				}

				ExpendRecord expeReco = new ExpendRecord();
				expeReco.setAddDate(expeDate.getText().toString());
				expeReco.setAddTypeIndex(addTypeIndex);
				expeReco.setAddTypeReturnIndex(RelativeInfo.judgeTypeLevel(2,
						addTypeIndex));
				expeReco.setAddNum(Double.valueOf(expeNum.getText().toString()
						.trim()));
				expeReco.setExpeRemark(expeRemark.getText().toString().trim());

				// ���÷����������ݲ���
				if (expeService.addExpend(expeReco) == true) {
					Toast.makeText(getActivity(), "����֧����¼�ɹ�", Toast.LENGTH_LONG)
							.show();
					expeNum.setText(null);
					expeRemark.setText(null);
				} else {
					Toast.makeText(getActivity(), "����֧����¼ʧ��", Toast.LENGTH_LONG)
							.show();
				}

			}
		});

		// ��ѯ��ʼ�������Ӽ����¼�
		expeDateQueryStart = (EditText) rootView
				.findViewById(R.id.expend_row5_edit1);
		expeDateQueryStart.setText(RelativeInfo.getMadeDate());
		expeDateQueryStart
				.setOnClickListener(new android.view.View.OnClickListener() {

					@Override
					public void onClick(View v) {
						Calendar c = Calendar.getInstance();
						// ֱ�Ӵ���һ��DatePickerDialog�Ի���ʵ������������ʾ����
						new DatePickerDialog(
								getActivity(),
								// �󶨼�����
								new DatePickerDialog.OnDateSetListener() {
									@Override
									public void onDateSet(DatePicker dp,
											int year, int month, int dayOfMonth) {
										expeDateQueryStart.setText(RelativeInfo
												.getFormatDate(year, month,
														dayOfMonth));
									}
								}
								// ���ó�ʼ����
								, c.get(Calendar.YEAR), c.get(Calendar.MONTH),
								c.get(Calendar.DAY_OF_MONTH)).show();
					}
				});

		// ��ѯ�����������Ӽ����¼�
		expeDateQueryEnd = (EditText) rootView
				.findViewById(R.id.expend_row5_edit2);
		expeDateQueryEnd.setText(RelativeInfo.getNowDate());
		expeDateQueryEnd
				.setOnClickListener(new android.view.View.OnClickListener() {

					@Override
					public void onClick(View v) {
						Calendar c = Calendar.getInstance();
						// ֱ�Ӵ���һ��DatePickerDialog�Ի���ʵ������������ʾ����
						new DatePickerDialog(
								getActivity(),
								// �󶨼�����
								new DatePickerDialog.OnDateSetListener() {
									@Override
									public void onDateSet(DatePicker dp,
											int year, int month, int dayOfMonth) {
										expeDateQueryEnd.setText(RelativeInfo
												.getFormatDate(year, month,
														dayOfMonth));
									}
								}
								// ���ó�ʼ����
								, c.get(Calendar.YEAR), c.get(Calendar.MONTH),
								c.get(Calendar.DAY_OF_MONTH)).show();
					}
				});

		// ��ѯ�������Ӽ����¼�
		expeTypeQuery = (EditText) rootView
				.findViewById(R.id.expend_row6_edit1);
		expeTypeQuery
				.setOnClickListener(new android.view.View.OnClickListener() {

					@Override
					public void onClick(View v) {
						expeTypeTag = 2;
						singleChoice(v);
					}
				});

		// ��ѯ��ť�¼�
		Button queryBtn = (Button) rootView.findViewById(R.id.expend_query_btn);
		queryBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				String startDateStr=expeDateQueryStart.getText().toString().trim();
                String endDateStr=expeDateQueryEnd.getText().toString().trim();

                
                if(startDateStr.compareTo(endDateStr)>0){
                	Toast.makeText(getActivity(),getString(R.string.date_error) ,Toast.LENGTH_LONG).show();
                	
                	return ;
                }
				
                
                int paramIndex=queryTypeIndex;
                //�жϲ�ѯ�������Ƿ�Ϊ��
                if("".equals( expeTypeQuery.getText().toString().trim() )||
                		expeTypeQuery.getText().toString()==null){
                	paramIndex=-1;
                }
				list.setAdapter(expeService.queryReceipts(startDateStr, endDateStr, paramIndex));

				sumView.setText("����:"
						+ String.valueOf(expeService.getAccountSum()) + "Ԫ");
			}
		});

		list = (ListView) rootView.findViewById(R.id.expend_simpleListView);
		// ΪListView����Adapter
		list.setAdapter(expeService.queryReceipts(RelativeInfo.getMadeDate(),
				RelativeInfo.getNowDate(), -1));
		sumView.setText("����:" + String.valueOf(expeService.getAccountSum())
				+ "Ԫ");
		// ΪListView���б�����¼����¼�������
		list.setOnItemClickListener(new OnItemClickListener() {
			// ��position�����ʱ�����÷�����
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
			}
		});
		list.setOnItemSelectedListener(new OnItemSelectedListener() {
			// ��position�ѡ��ʱ�����÷�����
			@Override
			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
			}

			@Override
			public void onNothingSelected(AdapterView<?> parent) {
			}
		});

		return rootView;
	}

	// ��������ѡ��Ի���
	public void singleChoice(View source) {
		int parmIndex=0;
		switch (expeTypeTag) {
		case 1:
			parmIndex=addTypeIndex;
			break;
		case 2:
			parmIndex=queryTypeIndex;
			break;
		default:
			break;
		}
		
		
		AlertDialog.Builder builder = new AlertDialog.Builder(getActivity())
		// ���öԻ������
				.setTitle(R.string.dialog_chose_expe)
				// ����ͼ��
				.setIcon(R.drawable.smile_sad)
				// ���õ�ѡ�б���,Ĭ��ѡ�еڶ������Ϊ1��
				.setSingleChoiceItems(items, parmIndex, new OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						switch (expeTypeTag) {
						case 1:
							addTypeIndex=which;
							break;
						case 2:
							queryTypeIndex=which;
							break;
						default:
							break;
						}
					}
				});
		// ΪAlertDialog.Builder���ӡ�ȷ������ť
		setPositiveButton(builder);
		// ΪAlertDialog.Builder���ӡ�ȡ������ť
		setNegativeButton(builder).create().show();
	}

	private AlertDialog.Builder setPositiveButton(AlertDialog.Builder builder) {
		// ����setPositiveButton��������ȷ����ť
		return builder.setPositiveButton(getString(R.string.dialog_config), new OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				// ���ܴ�����ȷ��which����
				switch (expeTypeTag) {
				case 1:
					expeType.setText(items[addTypeIndex].toString().trim());
					break;
				case 2:
					expeTypeQuery.setText(items[queryTypeIndex].toString().trim());
					break;
				default:
					break;
				}
			}
		});
	}

	private AlertDialog.Builder setNegativeButton(AlertDialog.Builder builder) {
		// ����setNegativeButton��������ȡ����ť
		return builder.setNegativeButton(getString(R.string.dialog_cancel), new OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				// ���ܴ�����ȷ��which����
				switch (expeTypeTag) {
				case 2:
					expeTypeQuery.setText("");
					queryTypeIndex = 0;
					break;
				default:
					break;
				}
			}
		});
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		ManagerDB.closeDBHelper(expeService.getDbHelper());
	}
}
