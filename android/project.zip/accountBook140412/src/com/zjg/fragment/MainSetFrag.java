package com.zjg.fragment;

import com.zjg.activity.R;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.app.Fragment;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;

/**
 * Description:
 * <br/>Date:2014/2/20
 * @author zhaoJianGuo 1527370012@qq.com
 * @version 1.0
 */
@TargetApi(Build.VERSION_CODES.HONEYCOMB_MR1)
public class MainSetFrag extends Fragment
{
    LinearLayout helpLL;
    LinearLayout softLL;
    LinearLayout developLL;
	
	boolean useHelpChecked=false;
	boolean softChecked=false;
	boolean developerChecked=false;
    
    
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
	}

	// ��д�÷������÷������ص�View����ΪFragment��ʾ�����
	@Override
	public View onCreateView(LayoutInflater inflater
		, ViewGroup container, Bundle savedInstanceState)
	{
		// ����/res/layout/Ŀ¼�µ�main_set_layout.xml�����ļ�
		View rootView = inflater.inflate(R.layout.main_set_layout,
				container, false);
		helpLL=(LinearLayout)rootView.findViewById(R.id.main_set_help_ll);
		softLL=(LinearLayout)rootView.findViewById(R.id.main_set_soft_ll);
		developLL=(LinearLayout)rootView.findViewById(R.id.main_set_developer_ll);
		
		
		
		Button useHelpBtn=(Button)rootView.findViewById(R.id.main_set_help_btn);
		useHelpBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				if(softChecked){
					showHideSoftText(false);
				}
				if(developerChecked){
					showHideDeveloperText(false);
				}
				if(!useHelpChecked){
					showHideHelpText(true);
				}
				useHelpChecked=true;
				softChecked=false;
				developerChecked=false;
			}
		});
		
		Button aboutSoftBtn=(Button)rootView.findViewById(R.id.main_set_soft_btn);
		aboutSoftBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				if(useHelpChecked){
					showHideHelpText(false);
				}
				if(developerChecked){
					showHideDeveloperText(false);
				}
				if(!softChecked){
					showHideSoftText(true);
				}
				softChecked=true;
				useHelpChecked=false;
				developerChecked=false;
			}
		});
		
		
		Button developerBtn=(Button)rootView.findViewById(R.id.main_set_developer_btn);
		developerBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				if(useHelpChecked){
					showHideHelpText(false);
				}
				if(softChecked){
					showHideSoftText(false);
				}
				if(!developerChecked){
					showHideDeveloperText(true);
				}
				developerChecked=true;
				useHelpChecked=false;
				softChecked=false; 
			}
		});
		
		
		return rootView;
	}
	
	@TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
	public void showHideHelpText(final boolean show){
		// ����ѡ��
		// ViewPropertyAnimator APIs�������ã����ж�����ʾ
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
			int shortAnimTime = getResources().getInteger(
					android.R.integer.config_shortAnimTime);

			helpLL.setVisibility(View.VISIBLE); 
			helpLL.animate().setDuration(shortAnimTime)
					.alpha(show ? 1 : 0)
					.setListener(new AnimatorListenerAdapter() {
						@Override
						public void onAnimationEnd(Animator animation) {
							helpLL.setVisibility(show ? View.VISIBLE
									: View.GONE);
						}
					});
		} else {
			// ViewPropertyAnimator APIs�����ã�ֱ�ӽ���������ʾ
			helpLL.setVisibility(show ? View.VISIBLE : View.GONE);
		}
	}
	
	@TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
	public void showHideSoftText(final boolean show){
		// ����ѡ��
		// ViewPropertyAnimator APIs�������ã����ж�����ʾ
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
			int shortAnimTime = getResources().getInteger(
					android.R.integer.config_shortAnimTime);

			softLL.setVisibility(View.VISIBLE); 
			softLL.animate().setDuration(shortAnimTime)
					.alpha(show ? 1 : 0)
					.setListener(new AnimatorListenerAdapter() {
						@Override
						public void onAnimationEnd(Animator animation) {
							softLL.setVisibility(show ? View.VISIBLE
									: View.GONE);
						}
					});
		} else {
			// ViewPropertyAnimator APIs�����ã�ֱ�ӽ���������ʾ
			softLL.setVisibility(show ? View.VISIBLE : View.GONE);
		}
	}
	
	@TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
	public void showHideDeveloperText(final boolean show){
		// ����ѡ��
		// ViewPropertyAnimator APIs�������ã����ж�����ʾ
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
			int shortAnimTime = getResources().getInteger(
					android.R.integer.config_shortAnimTime);

			developLL.setVisibility(View.VISIBLE); 
			developLL.animate().setDuration(shortAnimTime)
					.alpha(show ? 1 : 0)
					.setListener(new AnimatorListenerAdapter() {
						@Override
						public void onAnimationEnd(Animator animation) {
							developLL.setVisibility(show ? View.VISIBLE
									: View.GONE);
						}
					});
		} else {
			// ViewPropertyAnimator APIs�����ã�ֱ�ӽ���������ʾ
			developLL.setVisibility(show ? View.VISIBLE : View.GONE);
		}
	}
}
