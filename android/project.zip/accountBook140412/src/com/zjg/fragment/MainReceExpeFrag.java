package com.zjg.fragment;

import java.util.Calendar;

import android.app.DatePickerDialog;
import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.zjg.activity.R;
import com.zjg.db.ManagerDB;
import com.zjg.service.MainReceExpeService;
import com.zjg.util.MathUtils;
import com.zjg.util.RelativeInfo;

/**
 * Description: <br/>
 * Date:2014/2/20
 * 
 * @author zhaoJianGuo 1527370012@qq.com
 * @version 1.0
 */
public class MainReceExpeFrag extends Fragment {
	private MainReceExpeService service = null;

	private EditText receOfAll;
	private EditText expeOfAll;
	private EditText difValueOfAll;
	private EditText receFromSomeDay;
	private EditText expeFromSomeDay;
	private EditText difValueOfFromSomeDay;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

	// ��д�÷������÷������ص�View����ΪFragment��ʾ�����
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		View rootView = inflater.inflate(R.layout.main_rece_expe_layout,
				container, false);

		// ʵ����һ�����ݷ���
		service = new MainReceExpeService(getActivity());

		// Ϊ�ۼ���������¼��������
		double  inValue=service.getAllReceipts(RelativeInfo.userID);
		receOfAll = (EditText) rootView
				.findViewById(R.id.main_rece_expe_accountIn1);
		receOfAll.setText(    Double.toString(inValue)  );
		// Ϊ�ۼ�֧����¼��������
		double  outValue=service.getAllExpend(RelativeInfo.userID); 
		expeOfAll = (EditText) rootView
				.findViewById(R.id.main_rece_expe_accountOut1);
		expeOfAll.setText(   Double.toString(outValue)  );
		//Ϊ�ۼƼ�¼���ò��
		difValueOfAll = (EditText) rootView
				.findViewById(R.id.main_rece_expe_d_value81); 
		difValueOfAll.setText(   Double.toString(  MathUtils.formatDouble(inValue-outValue)   )  );
		
		// ������ĳ����������¼����
		inValue=Double.valueOf(   service.getReceiptsFromSomeDay(RelativeInfo.userID)[0]  );
		receFromSomeDay = (EditText) rootView
				.findViewById(R.id.main_rece_expe_accountIn2);
		receFromSomeDay.setText(   Double.toString(inValue)   );
		// ������ĳ�����֧����¼
		String[] str = new String[2];
		str = service.getExpendFromSomeDay(RelativeInfo.userID);
		outValue=Double.valueOf( str[0] );
		expeFromSomeDay = (EditText) rootView
				.findViewById(R.id.main_rece_expe_accountOut2);
		expeFromSomeDay.setText(str[0]);

		final TextView textView = (TextView) rootView
				.findViewById(R.id.main_rece_expe_title2);
		textView.setText("��" + str[1] + "�������ۼƼ�¼");

		ImageButton imageButton = (ImageButton) rootView
				.findViewById(R.id.main_rece_expe_calender);
		//������ĳ����Ĳ��
		difValueOfFromSomeDay = (EditText) rootView
				.findViewById(R.id.main_rece_expe_d_value91);
		difValueOfFromSomeDay.setText(   Double.toString(  MathUtils.formatDouble(inValue-outValue)   )  );
		
		
		
		// Ϊ������ť�����¼�
		imageButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Calendar c = Calendar.getInstance();
				// ֱ�Ӵ���һ��DatePickerDialog�Ի���ʵ������������ʾ����
				new DatePickerDialog(getActivity(),
				// �󶨼�����
						new DatePickerDialog.OnDateSetListener() {
							@Override
							public void onDateSet(DatePicker dp, int year,
									int month, int dayOfMonth) {
								String dateStr = year
										+ "/"
										+ RelativeInfo
												.modifyNumberFormat(month + 1)
										+ "/"
										+ RelativeInfo
												.modifyNumberFormat(dayOfMonth);
								double[] returnDouble = service
										.getReceExpeFromSomeDay(dateStr);
								if (returnDouble[2] == 1) {
									textView.setText("��" + dateStr + "�������ۼƼ�¼");
									receFromSomeDay.setText(String
											.valueOf(returnDouble[0]));
									expeFromSomeDay.setText(String
											.valueOf(returnDouble[1]));
									difValueOfFromSomeDay.setText(   Double.toString(  MathUtils.formatDouble(returnDouble[0]-returnDouble[1])   )  );
								}else if(returnDouble[2]==-1){
									Toast.makeText(getActivity(), "ͳ������ʧ�ܣ�", Toast.LENGTH_LONG).show();
								}
								
							}
						}
						// ���ó�ʼ����
						, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c
								.get(Calendar.DAY_OF_MONTH)).show();
			}
		});

		// ���ӽ�����֧Activity��ť�¼�����
		Button goReceExpeBtn = (Button) rootView
				.findViewById(R.id.main_rece_expe_goBtn);

		goReceExpeBtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent goReceExpeIntent = new Intent();
				goReceExpeIntent.setAction("ReceExpeActivity");
				startActivity(goReceExpeIntent);
			}
		});

		return rootView;
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		ManagerDB.closeDBHelper(service.getDbHelper());
	}
}
