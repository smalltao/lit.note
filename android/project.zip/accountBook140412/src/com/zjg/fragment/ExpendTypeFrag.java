package com.zjg.fragment;



import java.util.ArrayList;

import com.zjg.activity.R;
import com.zjg.service.ExpendTypeService;
import com.zjg.service.TypeInitService;
import com.zjg.util.RelativeInfo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup; 
import android.widget.BaseExpandableListAdapter;
import android.widget.EditText;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Description: <br/>
 * Date:2014/2/24
 * 
 * @author zhaoJianGuo 1527370012@qq.com
 * @version 1.0
 */
public class ExpendTypeFrag extends Fragment {
	private Activity myActivity = null;
	private ExpendTypeService service = null;
	private TypeInitService typeService=null;


	private String[] firstTypes = null;
	private ArrayList<String[]> secondTypes = null;
	
    //�������������б���ʾ
	private String[] items = null;
	private int whichType;
	
	private EditText firstTypeText = null;
	private EditText firstTypeTextDiag = null;
	private EditText secondTypeText=null;
    private ExpandableListView expandListView=null;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		myActivity = getActivity();
		service=new ExpendTypeService(myActivity);
		typeService=new TypeInitService(myActivity);
		
		initType();
		
	}

	// ��д�÷������÷������ص�View����ΪFragment��ʾ�����
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.expend_type, container, false);
		
		expandListView = (ExpandableListView) rootView
				.findViewById(R.id.expe_type_simpleListView);
		expandListView.setAdapter(adapter);
		firstTypeText = (EditText) rootView
				.findViewById(R.id.expe_type_f_type_text1);
		secondTypeText=(EditText)rootView.findViewById(R.id.expe_type_s_type_text);
		

		firstTypeTextDiag=(EditText)rootView.findViewById(R.id.expe_type_f_type_text2);
		// �������ͼ����¼�
		firstTypeTextDiag.setOnClickListener(new android.view.View.OnClickListener() {

			@Override
			public void onClick(View v) {
				singleChoice(v);
			}
		});
		
		rootView.findViewById(R.id.expe_type_first_add).setOnClickListener(
				new View.OnClickListener() {

					@Override
					public void onClick(View v) {
						String typeName = firstTypeText.getText().toString()
								.trim();
                        if(TextUtils.isEmpty(typeName)){
                        	firstTypeText.setError(getString(R.string.comm_required));
                        	firstTypeText.requestFocus();
                        	return ;
                        }
						
						
						if (service.isExitsFirstType(typeName)) {
							firstTypeText
									.setError(getString(R.string.rece_expe_exits));
						} else {
							//�Ƿ����һ�����ͳɹ�
							if (service.addFirstReceType(typeName)) {
								//���¼�����������
								typeService.loadExpeType(RelativeInfo.userID);
								//���³�ʼ����������
								initType();
								//���¼�����չ�б�
								expandListView.setAdapter(adapter);
								Toast.makeText(myActivity, "����һ��֧�����ͳɹ�",
										Toast.LENGTH_LONG).show();
							}else{
								Toast.makeText(myActivity, "����һ��֧������ʧ��",
										Toast.LENGTH_LONG).show();
							}
						}
					}
				});

        rootView.findViewById(R.id.expe_type_sece_add).setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				String firstTypeName = firstTypeTextDiag.getText().toString()
						.trim();
				String secoTypeName=secondTypeText.getText().toString().trim();
				
				
                if(TextUtils.isEmpty(firstTypeName)){
                	firstTypeTextDiag.setError(getString(R.string.comm_required));
                	return ;
                }
                if(TextUtils.isEmpty(secoTypeName)){
                	secondTypeText.setError(getString(R.string.comm_required));
                	secondTypeText.requestFocus();
                	return ;
                }
				
				if (service.isExitsSecoType(firstTypeName, secoTypeName) ) {
					secondTypeText
							.setError(getString(R.string.rece_expe_exits));
				} else {
					//�Ƿ����һ�����ͳɹ�
					if (service.addSecoReceType(firstTypeName, secoTypeName) ) {
						//���¼�����������
						typeService.loadExpeType(RelativeInfo.userID);
						//���³�ʼ����������
						initType();
						//���¼�����չ�б�
						expandListView.setAdapter(adapter);
						Toast.makeText(myActivity, "���Ӷ���֧�����ͳɹ�",
								Toast.LENGTH_LONG).show();
					}else{
						Toast.makeText(myActivity, "���Ӷ���֧������ʧ��",
								Toast.LENGTH_LONG).show();
					}
				}
			}
		});



		return rootView;
	}

	//��ʼ������֧������
	public void initType(){
		//��RelativeInfo���л�����ݣ���ʼ��֧������
		firstTypes=new String[RelativeInfo.expeFirstType.size()];
		firstTypes=RelativeInfo.expeFirstType.toArray(firstTypes);
		secondTypes=RelativeInfo.expeSecondType;
		
		//ʹ��RelativeInfo�е����ݳ�ʼ��items
		items=new String[RelativeInfo.expeFirstType.size()];
		items=RelativeInfo.expeFirstType.toArray(items);
	}
	
	ExpandableListAdapter adapter = new BaseExpandableListAdapter() {

		// ��ȡָ����λ�á�ָ�����б�������б�������
		@Override
		public Object getChild(int groupPosition, int childPosition) {
			return secondTypes.get(groupPosition)[childPosition];
		}

		@Override
		public long getChildId(int groupPosition, int childPosition) {
			return childPosition;
		}

		@Override
		public int getChildrenCount(int groupPosition) {
			return secondTypes.get(groupPosition).length;
		}



		// �÷�������ÿ����ѡ������
		@Override
		public View getChildView(int groupPosition, int childPosition,
				boolean isLastChild, View convertView, ViewGroup parent) {
			TextView textView = new TextView(myActivity);
			textView.setPadding(36, 0,0,0);
			textView.setCompoundDrawablesWithIntrinsicBounds(R.drawable.star_smile,0,0,0);
			textView.setText(getChild(groupPosition, childPosition).toString());
			return textView;
		}

		// ��ȡָ����λ�ô���������
		@Override
		public Object getGroup(int groupPosition) {
			return firstTypes[groupPosition];
		}

		@Override
		public int getGroupCount() {
			return firstTypes.length;
		}

		@Override
		public long getGroupId(int groupPosition) {
			return groupPosition;
		}

		// �÷�������ÿ����ѡ������
		@Override
		public View getGroupView(int groupPosition, boolean isExpanded,
				View convertView, ViewGroup parent) {
			LinearLayout ll = new LinearLayout(myActivity);
			ll.setOrientation(0);
			
			TextView bgTextView=new TextView(myActivity); 
			bgTextView.setHeight(R.dimen.list_height);
            
			bgTextView.setBackgroundResource(R.drawable.star);
			
			TextView textView = new TextView(myActivity);
			textView.setCompoundDrawablesWithIntrinsicBounds(R.drawable.star,0,0,0);
			textView.setText(getGroup(groupPosition).toString());
			ll.addView(textView);
			return ll;
		}

		@Override
		public boolean isChildSelectable(int groupPosition, int childPosition) {
			return true;
		}

		@Override
		public boolean hasStableIds() {
			return true;
		}
	};

	// ����һ��֧������ѡ��Ի���
	public void singleChoice(View source) {
		AlertDialog.Builder builder = new AlertDialog.Builder(getActivity())
		// ���öԻ������
				.setTitle(R.string.dialog_chose_f_expe_type)
				// ����ͼ��
				.setIcon(R.drawable.smile)
				// ���õ�ѡ�б���,Ĭ��ѡ�еڶ������Ϊ1��
				.setSingleChoiceItems(items, 0, new OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						whichType = which;
					}
				});
		// ΪAlertDialog.Builder���ӡ�ȷ������ť
		setPositiveButton(builder);
		// ΪAlertDialog.Builder���ӡ�ȡ������ť
		setNegativeButton(builder).create().show();
	}

	private AlertDialog.Builder setPositiveButton(AlertDialog.Builder builder) {
		// ����setPositiveButton��������ȷ����ť
		return builder.setPositiveButton(getString(R.string.dialog_config), new OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				firstTypeTextDiag.setText(items[whichType]);
			}
		});
	}

	private AlertDialog.Builder setNegativeButton(AlertDialog.Builder builder) {
		// ����setNegativeButton��������ȡ����ť
		return builder.setNegativeButton(getString(R.string.dialog_cancel), new OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
			}
		});
	}
}
