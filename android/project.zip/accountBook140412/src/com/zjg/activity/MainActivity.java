package com.zjg.activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Fragment;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnClickListener;
import android.os.Bundle;
import android.view.View;
import com.zjg.fragment.MainLendRetuFrag;
import com.zjg.fragment.MainMenuFrag;
import com.zjg.fragment.MainMoreFrag;
import com.zjg.fragment.MainReceExpeFrag;
import com.zjg.fragment.MainSetFrag;

/**
 * Description: project start date 2014/2/17<br/>
 * Date:2014/2/20
 * 
 * @author zhaoJianGuo 1527370012@qq.com
 * @version 1.0
 */
public class MainActivity extends Activity implements MainMenuFrag.Callbacks {
    Activity myActivity;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// ����/res/layoutĿ¼�µ�main_activity_layout.xml�����ļ�
		setContentView(R.layout.main_activity_layout);
        this.myActivity=this;
		
		Intent intent = getIntent();
		this.onItemSelected(intent.getIntExtra("whichFrag", 1));
	}

/*	@Override
	public void onStart() {
          super.onStart();
	}

	@Override
	public void onResume() {
		super.onResume();
		Intent intent = getIntent();
		this.onItemSelected(intent.getIntExtra("whichFrag", 2));
	}*/
    
	@Override
	public  void onBackPressed (){
		new AlertDialog.Builder(myActivity)
				// ���öԻ���ı���
				.setTitle(R.string.dialog_tip)
				// ���öԻ�����ʾ��View����
				.setMessage(R.string.dialog_quit)
				// Ϊ�Ի�������һ����ȷ������ť
				.setPositiveButton(getString(R.string.dialog_config), new OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						finish();
					}
				})
				// Ϊ�Ի�������һ����ȡ������ť
				.setNegativeButton(getString(R.string.dialog_cancel), new OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// ȡ�������κ����顣
					}
				})
				// �����Ի���
				.create().show();
	}
	
	// ʵ��Callbacks�ӿڱ���ʵ�ֵķ���
	@Override
	public void onItemSelected(Integer id) {
		View fragView=getFragmentManager().findFragmentById(R.id.main_menu_container).getView();
		
		View receView=fragView.findViewById(R.id.main_menu_rece_expe_btn);
		View lendRefundView=fragView.findViewById(R.id.main_menu_lend_retu_btn);
		View moreView=fragView.findViewById(R.id.main_menu_more_btn);
		View setView=fragView.findViewById(R.id.main_menu_set_btn);
		
		Fragment mainShowFragment = null;
		switch (id) {
		case 1:
			receView.setBackgroundResource(R.drawable.main_rece_expe_white);
            lendRefundView.setBackgroundResource(R.drawable.main_lend_retu);
            moreView.setBackgroundResource(R.drawable.main_more);
            setView.setBackgroundResource(R.drawable.main_set);
			mainShowFragment = new MainReceExpeFrag();
			break;
		case 2:
			receView.setBackgroundResource(R.drawable.main_rece_expe);
            lendRefundView.setBackgroundResource(R.drawable.main_lend_retu_white);
            moreView.setBackgroundResource(R.drawable.main_more);
            setView.setBackgroundResource(R.drawable.main_set);
			mainShowFragment = new MainLendRetuFrag();
			break;
		case 3:
			receView.setBackgroundResource(R.drawable.main_rece_expe);
            lendRefundView.setBackgroundResource(R.drawable.main_lend_retu);
            moreView.setBackgroundResource(R.drawable.main_more_white);
            setView.setBackgroundResource(R.drawable.main_set);
			mainShowFragment = new MainMoreFrag();
			break;
		case 4:
			receView.setBackgroundResource(R.drawable.main_rece_expe);
            lendRefundView.setBackgroundResource(R.drawable.main_lend_retu);
            moreView.setBackgroundResource(R.drawable.main_more);
            setView.setBackgroundResource(R.drawable.main_set_white);
			mainShowFragment = new MainSetFrag();
			break;
		default:
			receView.setBackgroundResource(R.drawable.main_rece_expe_white);
            lendRefundView.setBackgroundResource(R.drawable.main_lend_retu);
            moreView.setBackgroundResource(R.drawable.main_more);
            setView.setBackgroundResource(R.drawable.main_set);
			mainShowFragment = new MainReceExpeFrag();
			break;
		}

		getFragmentManager().beginTransaction()
				.replace(R.id.main_show_container, mainShowFragment).commit();
	}

}
