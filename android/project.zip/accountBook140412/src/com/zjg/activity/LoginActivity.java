package com.zjg.activity;

import com.zjg.db.ManagerDB;
import com.zjg.service.LoginService;
import com.zjg.service.TypeInitService;
import com.zjg.util.RelativeInfo;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Description: project start date 2014/2/17<br/>
 * Date:2014/2/27
 * 
 * @author zhaoJianGuo 1527370012@qq.com
 * @version 1.0
 */
public class LoginActivity extends Activity {
	private Activity activity = null;

	// ��ɵ�¼����
	private UserLoginTask mAuthTask = null;

	// ��¼�ķ�����
	private LoginService loginService = null;
	private TypeInitService typeService = null;

	private String uName;
	private String password;
	private boolean isHideRegView = true;

	// UI
	private EditText uNameView;
	private EditText passwordView;
	private CheckBox nameCheckBox;
	private CheckBox passwordCheckBox;
	private EditText regNameView;
	private EditText regPasswordView;
	private EditText regConPasswordView;
	private View mLoginFormView;
	private View mLoginStatusView;
	private View mRegisterView;
	private TextView mLoginStatusMessageView;

	private SharedPreferences prefences;
	private SharedPreferences.Editor edit;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.login_activity);

		activity = this;

		loginService = new LoginService(this);

		uNameView = (EditText) findViewById(R.id.login_acti_name);
		passwordView = (EditText) findViewById(R.id.login_acti_password);

		mLoginFormView = findViewById(R.id.login_form);
		mRegisterView = findViewById(R.id.register_form);
		mLoginStatusView = findViewById(R.id.login_status);
		mLoginStatusMessageView = (TextView) findViewById(R.id.login_status_message);

		// ע��Ԫ��
		regNameView = (EditText) findViewById(R.id.register_name);
		regPasswordView = (EditText) findViewById(R.id.register_password);
		regConPasswordView = (EditText) findViewById(R.id.register_config_password);

		// ������ס�ʺš�����ѡ���
		nameCheckBox = (CheckBox) findViewById(R.id.u_name_check_box);
		passwordCheckBox = (CheckBox) findViewById(R.id.password_check_box);
		// ȡ��SharedPreferences����
		prefences = getSharedPreferences("userInfo", MODE_PRIVATE);
		edit = prefences.edit();
		String preUserName = prefences.getString("uName", null);
		String prePassword = prefences.getString("password", null);

		if (preUserName != null) {
			uNameView.setText(preUserName);
			nameCheckBox.setChecked(true);
		}
		if (prePassword != null) {
			passwordView.setText(prePassword);
			passwordCheckBox.setChecked(true);
		}

		// ΪcheckBox�����¼�
		nameCheckBox
				.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

					@Override
					public void onCheckedChanged(CompoundButton buttonView,
							boolean isChecked) {
						// �����ѡ��
						if (isChecked) {
							String uName = uNameView.getText().toString()
									.trim();

							// �ж��������û����Ƿ�Ϊ��
							if (TextUtils.isEmpty(uName)) {
								buttonView.setChecked(false);
								Toast.makeText(activity, "�������û���", Toast.LENGTH_LONG).show();
								return;
							}
							else {// ��ǰ�û����Ϸ������д洢
								edit.remove("uName").putString("uName", uName).commit();
							}

						} else { // û�б�ѡ��
							// ������б��������
							edit.remove("uName").commit();
						}

					}
				});
		//Ϊ����Checkbox�����¼�
		passwordCheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				// �����ѡ��
				if (isChecked) {
					String password = passwordView.getText().toString()
							.trim();
                    
					// �ж������������Ƿ�Ϊ��
					if (TextUtils.isEmpty(password)) {
						buttonView.setChecked(false);
						Toast.makeText(activity, "����������", Toast.LENGTH_LONG).show();
						return;
					} else {// ���д洢
						edit.remove("password").putString("password", password).commit();
					}

				} else { // û�б�ѡ��
					// ������б��������
					edit.remove("password").commit();
				}			
			}
		});
		
		//Ϊ�ʺ�����������¼�
		uNameView.setOnTouchListener(new OnTouchListener() {
			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				nameCheckBox.setChecked(false);
				return false;
			}
		});

		passwordView.setOnTouchListener(new OnTouchListener() {
			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				passwordCheckBox.setChecked(false);
				return false;
			}
		});
		
		// ��¼�¼�
		findViewById(R.id.login_button).setOnClickListener(
				new View.OnClickListener() {
					@Override
					public void onClick(View view) {
						attemptLogin();
					}
				});

		// ��ʾ����ע������¼�
		findViewById(R.id.register_btn).setOnClickListener(
				new View.OnClickListener() {

					@Override
					public void onClick(View v) {
						// ����ע�᲼��״̬
						if (isHideRegView) {
							hideRegisterView(false);
							isHideRegView = false;
						} else {
							hideRegisterView(true);
							isHideRegView = true;
						}
					}
				});

		// ע���¼�
		findViewById(R.id.register_submit_btn).setOnClickListener(
				new View.OnClickListener() {

					@Override
					public void onClick(View v) {
						String name = regNameView.getText().toString().trim();
						String password = regPasswordView.getText().toString()
								.trim();
						String conPassword = regConPasswordView.getText()
								.toString().trim();

						register(name, password, conPassword);
                        
					}
				});
	}

	// ������ؼ��
	public void attemptLogin() {
		if (mAuthTask != null) {
			return;
		}

		uNameView.setError(null);
		passwordView.setError(null);

		uName = uNameView.getText().toString().trim();
		password = passwordView.getText().toString().trim();

		// ����û����Ƿ�Ϊ��
		if (TextUtils.isEmpty(uName)) {
			uNameView.setError(getString(R.string.login_field_required));
			uNameView.requestFocus();
			return;
		}

		// ��������Ƿ�Ϊ��
		if (TextUtils.isEmpty(password)) {
			passwordView.setError(getString(R.string.login_field_required));
			passwordView.requestFocus();
			return;
		}
		// ����Ƿ����Щ�û�
		if (!loginService.isContainName(uName)) {
			uNameView.setError(getString(R.string.login_not_exits_name));
			uNameView.requestFocus();
			return;
		}

		// ���е�¼
		mLoginStatusMessageView.setText(R.string.login_progress_signing_in);
		showProgress(true);
		mAuthTask = new UserLoginTask();
		mAuthTask.execute((Void) null);
	}

	public void register(String name, String password, String conPassword) {
		regNameView.setError(null);
		regPasswordView.setError(null);
		regConPasswordView.setError(null);

		// ע���û����Ƿ�Ϊ��
		if (TextUtils.isEmpty(name)) {
			regNameView.setError(getString(R.string.reg_name_required));
			regNameView.requestFocus();
			return;
		}
		// ע�������Ƿ�Ϊ��
		if (TextUtils.isEmpty(password)) {
			regPasswordView.setError(getString(R.string.reg_password_required));
			regPasswordView.requestFocus();
			return;
		}
		// ע��ȷ�������Ƿ�Ϊ��
		if (TextUtils.isEmpty(conPassword)) {
			regConPasswordView
					.setError(getString(R.string.reg_con_password_required));
			regConPasswordView.requestFocus();
			return;
		}

		if (!password.equals(conPassword)) {
			regConPasswordView
					.setError(getString(R.string.password_inconformity));
			regConPasswordView.requestFocus();
			return;
		}
		// ����Ƿ��Ѱ���Ҫע����û���
		if (loginService.isContainName(name)) {
			// Toast.makeText(activity, "�û����Ѵ��ڣ�",Toast.LENGTH_LONG).show();
			regNameView.setError(getString(R.string.uName_exits));
			regNameView.requestFocus();
			return;
		} else {
			if (loginService.register(name, password)) {
				regNameView.setText(null);
				regPasswordView.setText(null);
				regConPasswordView.setText(null);

				uNameView.setText(name);
				passwordView.setText(null);
				passwordView.requestFocus();
				
				nameCheckBox.setChecked(false);
				passwordCheckBox.setChecked(false);
				Toast.makeText(activity, "ע��ɹ������¼...", Toast.LENGTH_LONG)
						.show();
				
				
			} else {
				Toast.makeText(activity, "ע��ʧ��", Toast.LENGTH_LONG).show();
			}
		}

	}

	// ������Activity
	public void startMainActivity() {
		/*
		 * Bundle startBundle=new Bundle(); startBundle.putInt("userID", 1);
		 */

		Intent startIntent = new Intent();
		/* startIntent.putExtras(startBundle); */
		startIntent.setAction("mianActivity");

		startActivity(startIntent);
	}

	/**
	 * ��ʾ�����������ص�¼form
	 */
	@TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
	private void showProgress(final boolean show) {
		// ����ѡ��

		// ViewPropertyAnimator APIs�������ã����ж�����ʾ
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
			int shortAnimTime = getResources().getInteger(
					android.R.integer.config_shortAnimTime);

			mLoginStatusView.setVisibility(View.VISIBLE);
			mLoginStatusView.animate().setDuration(shortAnimTime)
					.alpha(show ? 1 : 0)
					.setListener(new AnimatorListenerAdapter() {
						@Override
						public void onAnimationEnd(Animator animation) {
							mLoginStatusView.setVisibility(show ? View.VISIBLE
									: View.GONE);
						}
					});

			mLoginFormView.setVisibility(View.VISIBLE);
			mLoginFormView.animate().setDuration(shortAnimTime)
					.alpha(show ? 0 : 1)
					.setListener(new AnimatorListenerAdapter() {
						@Override
						public void onAnimationEnd(Animator animation) {
							mLoginFormView.setVisibility(show ? View.GONE
									: View.VISIBLE);
						}
					});
			mRegisterView.setVisibility(View.VISIBLE);
			mRegisterView.animate().setDuration(shortAnimTime)
					.alpha(show ? 0 : 1)
					.setListener(new AnimatorListenerAdapter() {
						@Override
						public void onAnimationEnd(Animator animation) {
							mRegisterView.setVisibility(show ? View.GONE
									: View.VISIBLE);
						}
					});
		} else {
			// ViewPropertyAnimator APIs�����ã�ֱ�ӽ���������ʾ
			mLoginStatusView.setVisibility(show ? View.VISIBLE : View.GONE);
			mLoginFormView.setVisibility(show ? View.GONE : View.VISIBLE);
			mRegisterView.setVisibility(show ? View.GONE : View.VISIBLE);
		}
	}

	/**
	 * ��ʾ�����������ص�¼form
	 */
	@TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
	private void hideRegisterView(final boolean show) {
		// ����ѡ��

		// ViewPropertyAnimator APIs�������ã����ж�����ʾ
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
			int shortAnimTime = getResources().getInteger(
					android.R.integer.config_longAnimTime);

			mRegisterView.setVisibility(View.VISIBLE);
			mRegisterView.animate().setDuration(shortAnimTime)
					.alpha(show ? 0 : 1)
					.setListener(new AnimatorListenerAdapter() {
						@Override
						public void onAnimationEnd(Animator animation) {
							mRegisterView.setVisibility(show ? View.GONE
									: View.VISIBLE);
						}
					});
		} else {
			// ViewPropertyAnimator APIs�����ã�ֱ�ӽ���������ʾ
			mRegisterView.setVisibility(show ? View.GONE : View.VISIBLE);
		}
	}

	/**
	 * �����첽��¼
	 */
	public class UserLoginTask extends AsyncTask<Void, Void, Boolean> {
		@Override
		protected Boolean doInBackground(Void... params) {

			/*
			 * try {
			 * 
			 * Thread.sleep(1000); } catch (InterruptedException e) { }
			 */

			int uID = loginService.checkUser(uName, password);
			if (uID >= 0) {
				RelativeInfo.userID = uID;
				return true;
			} else {
				return false;
			}
		}

		@Override
		protected void onPostExecute(final Boolean success) {
			mAuthTask = null;
			showProgress(false);

			if (success) {
				typeService = new TypeInitService(activity);
				typeService.initialType();
				if (typeService != null) {
					ManagerDB.closeDBHelper(typeService.getDbHelper());
				}
				startMainActivity();
				finish();
			} else {
				passwordView
						.setError(getString(R.string.login_incorrect_password));
				passwordView.requestFocus();
			}
		}

		@Override
		protected void onCancelled() {
			mAuthTask = null;
			showProgress(false);
		}
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		ManagerDB.closeDBHelper(loginService.getDbHelper());
	}
}
