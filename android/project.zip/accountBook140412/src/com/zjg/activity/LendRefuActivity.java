package com.zjg.activity;

import java.util.Locale;

import com.zjg.fragment.LendFrag;
import com.zjg.fragment.RefundFrag;

import android.annotation.TargetApi;
import android.app.ActionBar;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.Menu;
import android.view.MenuItem;

public class LendRefuActivity extends FragmentActivity {

	/**
	 * Description: <br/>
	 * Date:2014/2/23
	 * 
	 * @author zhaoJianGuo 1527370012@qq.com
	 * @version 1.0
	 */
	SectionsPagerAdapter mSectionsPagerAdapter;

	/**
	 * The {@link ViewPager} that will host the section contents.
	 */
	ViewPager mViewPager;

	@TargetApi(Build.VERSION_CODES.ICE_CREAM_SANDWICH)
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.rece_expe_activity);

		// ������ͼ������Ϊ�ɵ����ͼ�꣬����󷵻���Activity
		ActionBar actionBar = getActionBar();
		actionBar.setDisplayShowHomeEnabled(true);
		actionBar.setHomeButtonEnabled(true); // ��api�汾������,ֻ֧��api14��android4.0�������ϰ汾
		// actionBar.setDisplayHomeAsUpEnabled(true);

		// Create the adapter that will return a fragment for each of the three
		// primary sections of the app.
		mSectionsPagerAdapter = new SectionsPagerAdapter(
				getSupportFragmentManager());

		// Set up the ViewPager with the sections adapter.
		mViewPager = (ViewPager) findViewById(R.id.pager);
		
		mViewPager.setAdapter(mSectionsPagerAdapter);

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		// getMenuInflater().inflate(R.menu.rece_expe_activity, menu);
		return false;
	}

	@Override
	public  void onBackPressed (){
		Intent intent = new Intent(LendRefuActivity.this,
				MainActivity.class);
		intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		intent.putExtra("whichFrag",2);
		startActivity(intent);
	}
	
	// ѡ��˵��Ĳ˵��������Ļص�����
	@Override
	public boolean onOptionsItemSelected(MenuItem mi) {

		// �жϵ��������ĸ��˵��������Ե�������Ӧ��
		switch (mi.getItemId()) {
		case android.R.id.home:

			Intent intent = new Intent(LendRefuActivity.this,
					MainActivity.class);
			intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			intent.putExtra("whichFrag",2);
			startActivity(intent);
			break;
		default:
			Intent intent1 = new Intent(LendRefuActivity.this,
					MainActivity.class);
			intent1.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			intent1.putExtra("whichFrag",2);
			startActivity(intent1);
		}
		return true;
	}

	/**
	 * A {@link FragmentPagerAdapter} that returns a fragment corresponding to
	 * one of the sections/tabs/pages.
	 */
	public class SectionsPagerAdapter extends FragmentPagerAdapter {

		public SectionsPagerAdapter(FragmentManager fm) {
			super(fm);
		}

		@Override
		public Fragment getItem(int position) {
			// getItem is called to instantiate the fragment for the given page.
			// Return a DummySectionFragment (defined as a static inner class
			// below) with the page number as its lone argument.
			Fragment fragment = null;

			switch (position) {
			case 0:
				fragment = new LendFrag();
				break;
			case 1:
				fragment = new RefundFrag();
				break;
			default:
				fragment = new LendFrag();
				break;
			}

			return fragment;
		}

		@Override
		public int getCount() {
			// Show 3 total pages.
			return 2;
		}

		@Override
		public CharSequence getPageTitle(int position) {
			switch (position) {
			case 0:
			return getString(R.string.lend_title).toUpperCase(
						Locale.CHINESE);
			case 1:
				return getString(R.string.refund_title).toUpperCase(  
						Locale.CHINESE); 
			}
			return null;
		}
	}

}
