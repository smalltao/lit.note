package com.zjg.service;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.zjg.db.ManagerDB;
import com.zjg.db.MyDatabaseHelper;
import com.zjg.util.RelativeInfo;


/**
 * Description: project start date 2014/2/17<br/>
 * Date:2014/3/5
 * 
 * @author zhaoJianGuo 1527370012@qq.com
 * @version 1.0
 */
public class ReceiptsTypeService {
	private MyDatabaseHelper dbHelper;
    private SQLiteDatabase dbConn;
	
	public ReceiptsTypeService(Context context){
		setDbHelper(ManagerDB.getDBHelper(context));
		
    }

    //�ж��Ƿ����ָ�����Ƶ�һ����������
    public boolean isExitsFirstType(String name){
    	boolean flag=false;
    	dbConn=ManagerDB.getDBConn(dbHelper);
    	
    	Cursor cursor=dbConn.query("receipts_type",
				new String[] {"_id"},"receipts_type=='"+name+
				                     "' and (is_sys_own==" + 1 + " or ref_user_tab_id=="+RelativeInfo.userID+")"+
						             "  and parent_id=="+-1,
				null, null, null, null, null);
    	if(cursor.getCount()>0)
    		flag=true;
    	cursor.close();
    	
        return flag;
    }
	
    //����һ������
    public boolean addFirstReceType(String typeName){
    	boolean addFlag=false;
    	dbConn = ManagerDB.getDBConn(dbHelper);
    	
    	ContentValues values = new ContentValues();

    	dbConn.beginTransaction();
		try {
			//��ʼ�����е�����
			values.put("parent_id",-1);
			values.put("receipts_type", typeName);
            values.put("is_sys_own",false);
			values.put("ref_user_tab_id", RelativeInfo.userID); 
			
			dbConn.insert("receipts_type", null, values);
			dbConn.setTransactionSuccessful();
			addFlag = true;
		} finally {
			dbConn.endTransaction();
		}
		
    	return addFlag;
    }
    
    //�ж��Ƿ����ָ�����ƵĶ�����������
    public boolean isExitsSecoType(String firstTypeName,String SecondTypeName){
    	boolean flag=false;
    	dbConn=ManagerDB.getDBConn(dbHelper);
    	
    	Cursor cursor=dbConn.query("receipts_type",
				new String[] {"_id"},"receipts_type=='"+SecondTypeName+
				                     "' and  parent_id=="+queryIDByReceName(firstTypeName),
				null, null, null, null, null);
    	if(cursor.getCount()>0)
    		flag=true;
    	cursor.close();
    	
        return flag;
    }
    
    //
    //���Ӷ�������
    public boolean addSecoReceType(String firstTypeName,String SecondTypeName){
    	boolean addFlag=false;
    	dbConn = ManagerDB.getDBConn(dbHelper);
    	
    	ContentValues values = new ContentValues();

    	dbConn.beginTransaction();
		try {
			//��ʼ�����е�����
			values.put("parent_id",queryIDByReceName(firstTypeName));
			values.put("receipts_type", SecondTypeName);
            values.put("is_sys_own",false);
			values.put("ref_user_tab_id", RelativeInfo.userID); 
			
			dbConn.insert("receipts_type", null, values);
			dbConn.setTransactionSuccessful();
			addFlag = true;
		} finally {
			dbConn.endTransaction();
		}
		
    	return addFlag;
    }
    public int queryIDByReceName(String name){
    	int returnID;
    	
    	dbConn=ManagerDB.getDBConn(dbHelper);
    	
    	Cursor cursor=dbConn.query("receipts_type",
				new String[] {"_id"},"receipts_type=='"+name+
				                     "' and (is_sys_own==" + 1 + " or ref_user_tab_id=="+RelativeInfo.userID+")"+
						             "  and parent_id=="+-1,
				null, null, null, null, null);
    	cursor.moveToFirst();
    	returnID=cursor.getInt(0);
    	cursor.close();
    	
    	return returnID;
    }
	public void setDbHelper(MyDatabaseHelper dbHelper) {
		this.dbHelper = dbHelper;
	}

	public MyDatabaseHelper getDbHelper() {
		return dbHelper;
	}
	
	
}
