package com.zjg.service;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.zjg.db.ManagerDB;
import com.zjg.db.MyDatabaseHelper;
import com.zjg.util.RelativeInfo;

/**
 * Description: project start date 2014/2/17<br/>
 * Date:2014/2/27
 * 
 * @author zhaoJianGuo 1527370012@qq.com
 * @version 1.0
 */
public class LoginService {

	private MyDatabaseHelper dbHelper;
	private SQLiteDatabase dbConn;

	public LoginService(Context context) {
		setDbHelper(ManagerDB.getDBHelper(context));

	}

	// ����Ƿ���ڴ��û�
	public boolean isContainName(String uName) {
		Cursor value = dbHelper.getReadableDatabase().query("user_tab",
				new String[] { "_id", "u_name" }, "u_name=='" + uName + "'",
				null, null, null, null, null);

		if (value.getCount() == 1) {
			value.close();
			return true;
		} else {
			value.close();
			return false;
		}
	}

	// ����û����������Ƿ���ȷ
	public int checkUser(String uName, String password) {
		Cursor value = dbHelper.getReadableDatabase().query("user_tab",
				new String[] { "_id", "u_name", "password" },
				"u_name=='" + uName + "' and password=='" + password + "'",
				null, null, null, null, null);

		if (value.getCount() == 1) {
			value.moveToFirst();
			int returnInt = value.getInt(0);
			value.close();
			return returnInt;
		} else {
			value.close();
			return -1;
		}
	}

	public boolean register(String name, String password) {
		boolean regFlag = false;

		dbConn = ManagerDB.getDBConn(dbHelper);

		ContentValues values = new ContentValues();
		dbConn.beginTransaction();

		try {

			values.put("u_name", name);
			values.put("password", password);
			long insertID = dbConn.insert("user_tab", null, values);
			//��ʼ�����е�����
			values.clear();
			values.put("account_name", "allRece");
			values.put("account_data", 0.0);
			values.put("ref_user_tab_id", insertID);
			dbConn.insert("account_tab", null, values);
			//��ʼ����ĳ�������������
			values.clear();
			values.put("account_name", "receFromSomeday");
			values.put("account_data", 0.0);
			values.put("start_date", RelativeInfo.getNowDate());
			values.put("ref_user_tab_id", insertID);
			dbConn.insert("account_tab", null, values);
			//��ʼ�����е�֧����ֵ
			values.clear();
			values.put("account_name", "allExpe");
			values.put("account_data", 0.0);
			values.put("ref_user_tab_id", insertID);
			dbConn.insert("account_tab", null, values);
			//��ʼ����ĳ���������֧����ֵ
			values.clear();
			values.put("account_name", "expeFromSomeday");
			values.put("account_data", 0.0);
			values.put("start_date", RelativeInfo.getNowDate());
			values.put("ref_user_tab_id", insertID);
			dbConn.insert("account_tab", null, values);

			//��ʼ����������Ŀ
			values.clear();
			values.put("account_name", "lendNum");
			values.put("account_data", 0);
			values.put("ref_user_tab_id", insertID);
			dbConn.insert("account_tab", null, values);
			//��ʼ����������ֵ
			values.clear();
			values.put("account_name", "lendSum");
			values.put("account_data", 0);
			values.put("ref_user_tab_id", insertID);
			dbConn.insert("account_tab", null, values);
			//��ʼ����������Ŀ
			values.clear();
			values.put("account_name", "borrowNum");
			values.put("account_data", 0);
			values.put("ref_user_tab_id", insertID);
			dbConn.insert("account_tab", null, values);
            //��ʼ����������ֵ
			values.clear();
			values.put("account_name", "borrowSum");
			values.put("account_data", 0);
			values.put("ref_user_tab_id", insertID);
			dbConn.insert("account_tab", null, values);
			
			dbConn.setTransactionSuccessful();
			regFlag = true;
		} finally {
			dbConn.endTransaction();
		}

		return regFlag;
	}

	public void setDbHelper(MyDatabaseHelper dbHelper) {
		this.dbHelper = dbHelper;
	}

	public MyDatabaseHelper getDbHelper() {
		return dbHelper;
	}

}
