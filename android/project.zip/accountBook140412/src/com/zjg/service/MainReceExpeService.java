package com.zjg.service;

import java.math.BigDecimal;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.zjg.db.ManagerDB;
import com.zjg.db.MyDatabaseHelper;
import com.zjg.util.MathUtils;
import com.zjg.util.RelativeInfo;

/**
 * Description: project start date 2014/2/17<br/>
 * Date:2014/2/25
 * 
 * @author zhaoJianGuo 1527370012@qq.com
 * @version 1.0
 */
public class MainReceExpeService {

	private MyDatabaseHelper dbHelper;
	private SQLiteDatabase dbConn;
	private Cursor serCursor;

	public MainReceExpeService(Context context) {
		setDbHelper(ManagerDB.getDBHelper(context));

	}

	/**
	 * ���ش��м�¼�����������
	 * 
	 * @return
	 */
	public double getAllReceipts(int userID) {
		serCursor = ManagerDB.getDBConn(dbHelper).query("account_tab",
				new String[] { "_id", "account_data" },
				"account_name=='allRece' and ref_user_tab_id==" + userID + "",
				null, null, null, null, null);
		serCursor.moveToFirst();
		double returnDouble = serCursor.getDouble(1);
		serCursor.close();
		//����С�����λ��
		returnDouble = MathUtils.formatDouble(returnDouble);
		return returnDouble;
	}

	/**
	 * ��ѯ��ĳ����������֧���еļ�¼��
	 * 
	 * @return double[0]Ϊ����� double[1]Ϊ֧����
	 *         double[2]����-1��ʾ�����쳣��double[2]����1��ʾִ�гɹ�
	 */
	public double[] getReceExpeFromSomeDay(String startDate) {
		double[] receExpe = new double[3];
		receExpe[0] = 0;
		receExpe[1] = 0;
		receExpe[2] = -1;

		serCursor = ManagerDB.getDBConn(dbHelper).query(
				"receipts_tab",
				new String[] { "rec_data" },
				"ref_user_tab_id==" + RelativeInfo.userID + " and rec_date>='"
						+ startDate + "'", null, null, null, null, null);
		BigDecimal bigDec = new BigDecimal(receExpe[0]);
		while (serCursor.moveToNext()) {
			bigDec=bigDec.add(new BigDecimal(serCursor.getDouble(0)));
		}
		receExpe[0] = MathUtils.formatDouble(bigDec.doubleValue());
		serCursor.close();

		serCursor = ManagerDB.getDBConn(dbHelper).query(
				"expend_tab",
				new String[] { "exp_data" },
				"ref_user_tab_id==" + RelativeInfo.userID + " and exp_date>='"
						+ startDate + "'", null, null, null, null, null);
		BigDecimal bigDec1 = new BigDecimal(receExpe[1]);
		while (serCursor.moveToNext()) {
			bigDec1 =bigDec1.add(new BigDecimal(serCursor.getDouble(0)));
		}
		receExpe[1] = MathUtils.formatDouble(bigDec1.doubleValue());
		serCursor.close();

		// ������ͳ�Ʊ�
		String updateReceAccontFromSomeDay = "update account_tab set account_data="
				+ receExpe[0]
				+ ", start_date='"
				+ startDate
				+ "'  where account_name=='receFromSomeday' and ref_user_tab_id=="
				+ RelativeInfo.userID;
		// ������ͳ�Ʊ�
		String updateExpeAccontFromSomeDay = "update account_tab set account_data="
				+ receExpe[1]
				+ ", start_date='"
				+ startDate
				+ "'  where account_name=='expeFromSomeday' and ref_user_tab_id=="
				+ RelativeInfo.userID;

		dbConn = ManagerDB.getDBConn(dbHelper);
		dbConn.beginTransaction();
		try {
			dbConn.execSQL(updateReceAccontFromSomeDay);
			dbConn.execSQL(updateExpeAccontFromSomeDay);

			dbConn.setTransactionSuccessful();
			receExpe[2] = 1;
		} finally {
			dbConn.endTransaction();
		}

		//����С�����λ��
		receExpe[0] = MathUtils.formatDouble(receExpe[0]);
		receExpe[1] = MathUtils.formatDouble(receExpe[1]);

		return receExpe;
	}

	/**
	 * ���ش�ĳһ���������������
	 * 
	 * @return
	 */
	public String[] getReceiptsFromSomeDay(int userID) {
		String[] str = new String[2];

		serCursor = ManagerDB.getDBConn(dbHelper).query(
				"account_tab",
				new String[] { "_id", "account_data", "start_date" },
				"account_name=='receFromSomeday' and ref_user_tab_id=="
						+ userID + "", null, null, null, null, null);
		serCursor.moveToFirst();

		str[0] = Double.toString(serCursor.getDouble(1));
		str[1] = serCursor.getString(2);

		serCursor.close();
		//����С�����λ��
		str[0] = MathUtils.formatDoubleOfString(str[0]);

		return str;
	}

	/**
	 * ���ش��м�¼�������֧��
	 * 
	 * @return
	 */
	public double getAllExpend(int userID) {
		serCursor = ManagerDB.getDBConn(dbHelper).query("account_tab",
				new String[] { "_id", "account_data" },
				"account_name=='allExpe' and ref_user_tab_id==" + userID + "",
				null, null, null, null, null);
		serCursor.moveToFirst();
		double returnDouble = serCursor.getDouble(1);
		serCursor.close();
		//����С�����λ��
		returnDouble = MathUtils.formatDouble(returnDouble);
		return returnDouble;
	}

	/**
	 * ���ش�ĳһ�����������֧��
	 * 
	 * @return str[0]Ϊ��ֵ��str[1]Ϊ����
	 */
	public String[] getExpendFromSomeDay(int userID) {
		String[] str = new String[2];

		serCursor = ManagerDB.getDBConn(dbHelper).query(
				"account_tab",
				new String[] { "_id", "account_data", "start_date" },
				"account_name=='expeFromSomeday' and ref_user_tab_id=="
						+ userID + "", null, null, null, null, null);
		serCursor.moveToFirst();

		str[0] = Double.toString(serCursor.getDouble(1));
		str[1] = serCursor.getString(2);

		serCursor.close();
		//����С�����λ��
		str[0] =  MathUtils.formatDoubleOfString(str[0]);
		return str;
	}

	public void setDbHelper(MyDatabaseHelper dbHelper) {
		this.dbHelper = dbHelper;
	}

	public MyDatabaseHelper getDbHelper() {
		return dbHelper;
	}

}
