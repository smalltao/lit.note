package com.zjg.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.SimpleAdapter;

import com.zjg.activity.R;
import com.zjg.db.ManagerDB;
import com.zjg.db.MyDatabaseHelper;
import com.zjg.model.ExpendRecord;
import com.zjg.util.MathUtils;
import com.zjg.util.RelativeInfo;

/**
 * Description: project start date 2014/2/17<br/>
 * Date:2014/3/3
 * 
 * @author zhaoJianGuo 1527370012@qq.com
 * @version 1.0
 */
public class ExpendService {
	private Context context;

	private MyDatabaseHelper dbHelper;
	private SQLiteDatabase dbConn;

	private double accountSum = 0;

	public ExpendService(Context context) {
		setDbHelper(ManagerDB.getDBHelper(context));
		this.context = context;

	}

	public boolean addExpend(ExpendRecord expeReco) {
		boolean addFlag = false;
		ContentValues values = new ContentValues();

		values.put("exp_gene_type", expeReco.getexpe_gene_type());
		values.put("exp_detail_type", expeReco.getexpe_detail_type());
		values.put("exp_data", expeReco.getAddNum());
		values.put("exp_date", expeReco.getAddDate());
		values.put("exp_register_date", RelativeInfo.getNowDate());
		values.put("remark", expeReco.getExpeRemark());
		values.put("ref_user_tab_id", RelativeInfo.userID);

		String updateAccontAll = "update account_tab set account_data=account_data+"
				+ expeReco.getAddNum()
				+ "  where account_name=='allExpe' and ref_user_tab_id=="
				+ RelativeInfo.userID;
		String updateAccontFromSomeDay = "update account_tab set account_data=account_data+"
				+ expeReco.getAddNum()
				+ "  where account_name=='expeFromSomeday' and ref_user_tab_id=="
				+ RelativeInfo.userID
				+ "  and start_date<='"
				+ expeReco.getAddDate() + "'";

		dbConn = ManagerDB.getDBConn(dbHelper);

		dbConn.beginTransaction();
		try {
			dbConn.insert("expend_tab", null, values);
			dbConn.execSQL(updateAccontAll);
			dbConn.execSQL(updateAccontFromSomeDay);

			dbConn.setTransactionSuccessful();
			addFlag = true;
		} finally {
			dbConn.endTransaction();
		}

		return addFlag;
	}

	/**
	 * �������ڲ�ѯ��ؼ�¼
	 */
	public SimpleAdapter queryReceipts(String startDate, String endDate,
			int typeIndex) {
		dbConn = ManagerDB.getDBConn(dbHelper);

		String whereStr = " ref_user_tab_id==" + RelativeInfo.userID
				+ " and exp_date>='" + startDate + "' and exp_date<='"
				+ endDate + "' ";
		if (typeIndex != -1) {
			String wherePart;
			int returnIndex = RelativeInfo.judgeTypeLevel(2, typeIndex);
			if (typeIndex == returnIndex) {
				wherePart = " and exp_gene_type=='"
						+ RelativeInfo.expeAllType.get(typeIndex).trim() + "'";
			} else {
				wherePart = " and exp_detail_type=='"
						+ RelativeInfo.expeAllType.get(typeIndex).trim() + "'";
			}
			whereStr += wherePart;
		}

		Cursor cursor = dbConn.query("expend_tab", new String[] { "exp_date",
				"exp_gene_type", "exp_detail_type", "exp_data", "remark" },
				whereStr, null, null, null, " exp_date desc ", null);
		SimpleAdapter simpleAdapter = createSimpleAdapter(cursor);
		cursor.close();
		return simpleAdapter;
	}

	private SimpleAdapter createSimpleAdapter(Cursor cursor) {
		int i = 1;
		BigDecimal bigDec = new BigDecimal(0);
		// ���б������ֵ
		List<Map<String, Object>> listItems = new ArrayList<Map<String, Object>>();
		while (cursor.moveToNext()) {
			Map<String, Object> listItem = new HashMap<String, Object>();
			listItem.put("sequence", i++);
			listItem.put("date", cursor.getString(0).substring(2));
			listItem.put("firstType", cursor.getString(1));
			listItem.put("secoType", cursor.getString(2));
			listItem.put("num", cursor.getDouble(3));
			bigDec =bigDec.add(new BigDecimal(cursor.getDouble(3)));
			listItem.put("remark", cursor.getString(4));
			listItems.add(listItem);

		}
		accountSum = MathUtils.formatDouble(bigDec.doubleValue());

		// ����һ��SimpleAdapter
		return new SimpleAdapter(context, listItems, R.layout.expe_simple_item,
				new String[] { "sequence", "date", "firstType", "secoType",
						"num", "remark" }, new int[] { R.id.expe_list_sequence,
						R.id.expe_list_date, R.id.expe_list_first_type,
						R.id.expe_list_seco_type, R.id.expe_list_num,
						R.id.expe_list_remark });
	}

	public void setDbHelper(MyDatabaseHelper dbHelper) {
		this.dbHelper = dbHelper;
	}

	public MyDatabaseHelper getDbHelper() {
		return dbHelper;
	}

	public SQLiteDatabase getDbConn() {
		return dbConn;
	}

	public void setDbConn(SQLiteDatabase dbConn) {
		this.dbConn = dbConn;
	}

	public double getAccountSum() {
		return accountSum;
	}

	public void setAccountSum(double accountSum) {
		this.accountSum = accountSum;
	}

}
