package com.zjg.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.SimpleAdapter;

import com.zjg.activity.R;
import com.zjg.db.ManagerDB;
import com.zjg.db.MyDatabaseHelper;
import com.zjg.util.MathUtils;
import com.zjg.util.RelativeInfo;

/**
 * Description: project start date 2014/2/17<br/>
 * Date:2014/3/4
 * 
 * @author zhaoJianGuo 1527370012@qq.com
 * @version 1.0
 */
public class RefundService {
	private Context context;

	private MyDatabaseHelper dbHelper;
	private SQLiteDatabase dbConn;

	private double accountSum = 0;

	public RefundService(Context context) {
		setDbHelper(ManagerDB.getDBHelper(context));
		this.context = context;
	}

	public SimpleAdapter queryRefund(String startDate, String endDate,
			boolean lendOrBorrow) {
		SimpleAdapter simpleAdapter = null;

		dbConn = ManagerDB.getDBConn(dbHelper);

		String whereStr = " ref_user_tab_id==" + RelativeInfo.userID
				+ " and refund_date>='" + startDate + "' and refund_date<='"
				+ endDate + "' ";
		String wherePart;
		if (lendOrBorrow) {
			wherePart = " and lend_or_borrow==" + 1 + " ";
		} else {
			wherePart = " and lend_or_borrow==" + 0 + " ";
		}
		whereStr += wherePart;

		Cursor cursor = dbConn.query("refund_tab", new String[] {
				"refund_date", "relate_person", "refund_data", }, whereStr,
				null, null, null, " refund_date desc ", null);
		simpleAdapter = createSimpleAdapter(cursor);
		cursor.close();

		return simpleAdapter;
	}

	private SimpleAdapter createSimpleAdapter(Cursor cursor) {
		int i = 1;
		BigDecimal bigDec = new BigDecimal(0); 
		// ���б������ֵ
		List<Map<String, Object>> listItems = new ArrayList<Map<String, Object>>();
		while (cursor.moveToNext()) {
			Map<String, Object> listItem = new HashMap<String, Object>();
			listItem.put("sequence", i++);
			listItem.put("date", cursor.getString(0).substring(2));
			listItem.put("lendWho", cursor.getString(1));
			listItem.put("num", cursor.getDouble(2));
			bigDec=bigDec.add(new BigDecimal(cursor.getDouble(2)));
			listItems.add(listItem);

		}
		accountSum = MathUtils.formatDouble(bigDec.doubleValue());

		// ����һ��SimpleAdapter
		return new SimpleAdapter(context, listItems,
				R.layout.refund_simple_item, new String[] { "sequence", "date",
						"lendWho", "num" }, new int[] {
						R.id.refund_list_sequence, R.id.refund_list_date,
						R.id.refund_list_name, R.id.refund_list_num });
	}

	public void setDbHelper(MyDatabaseHelper dbHelper) {
		this.dbHelper = dbHelper;
	}

	public MyDatabaseHelper getDbHelper() {
		return dbHelper;
	}

	public double getAccountSum() {
		return accountSum;
	}

	public void setAccountSum(double accountSum) {
		this.accountSum = accountSum;
	}

}
