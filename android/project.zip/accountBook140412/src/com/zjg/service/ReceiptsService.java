package com.zjg.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.SimpleAdapter;

import com.zjg.activity.R;
import com.zjg.db.ManagerDB;
import com.zjg.db.MyDatabaseHelper;
import com.zjg.model.ReceiptsRecord;
import com.zjg.util.MathUtils;
import com.zjg.util.RelativeInfo;

/**
 * Description: project start date 2014/2/17<br/>
 * Date:2014/3/1
 * 
 * @author zhaoJianGuo 1527370012@qq.com
 * @version 1.0
 */
public class ReceiptsService {
	private Context context;

	private MyDatabaseHelper dbHelper;
	private SQLiteDatabase dbConn;

	private double accountSum = 0;

	public ReceiptsService(Context context) {
		setDbHelper(ManagerDB.getDBHelper(context));
		this.context = context;

	}

	public boolean addReceipts(ReceiptsRecord receReco) {
		boolean addFlag = false;
		ContentValues values = new ContentValues();

		values.put("rec_gene_type", receReco.getRec_gene_type());
		values.put("rec_detail_type", receReco.getRec_detail_type());
		values.put("rec_data", receReco.getAddNum());
		values.put("rec_date", receReco.getAddDate());
		values.put("rec_register_date", RelativeInfo.getNowDate());
		values.put("remark", receReco.getReceRemark());
		values.put("ref_user_tab_id", RelativeInfo.userID);

		String updateAccontAll = "update account_tab set account_data=account_data+"
				+ receReco.getAddNum()
				+ "  where account_name=='allRece' and ref_user_tab_id=="
				+ RelativeInfo.userID;
		String updateAccontFromSomeDay = "update account_tab set account_data=account_data+"
				+ receReco.getAddNum()
				+ "  where account_name=='receFromSomeday' and ref_user_tab_id=="
				+ RelativeInfo.userID
				+ "  and start_date<='"
				+ receReco.getAddDate() + "'";

		dbConn = ManagerDB.getDBConn(dbHelper);

		dbConn.beginTransaction();
		try {
			dbConn.insert("receipts_tab", null, values);
			dbConn.execSQL(updateAccontAll);
			dbConn.execSQL(updateAccontFromSomeDay);

			dbConn.setTransactionSuccessful();
			addFlag = true;
		} finally {
			dbConn.endTransaction();
		}

		return addFlag;
	}

	/**
	 * �������ڲ�ѯ��ؼ�¼
	 */
	public SimpleAdapter queryReceipts(String startDate, String endDate,
			int typeIndex) {
		dbConn = ManagerDB.getDBConn(dbHelper);

		String whereStr = " ref_user_tab_id==" + RelativeInfo.userID
				+ " and rec_date>='" + startDate + "' and rec_date<='"
				+ endDate + "' ";
		if (typeIndex != -1) {
			String wherePart;
			int returnIndex = RelativeInfo.judgeTypeLevel(1, typeIndex);
			if (typeIndex == returnIndex) {
				wherePart = " and rec_gene_type=='"
						+ RelativeInfo.receAllType.get(typeIndex).trim() + "'";
			} else {
				wherePart = " and rec_detail_type=='"
						+ RelativeInfo.receAllType.get(typeIndex).trim() + "'";
			}
			whereStr += wherePart;
		}

		Cursor cursor = dbConn.query("receipts_tab", new String[] { "rec_date",
				"rec_gene_type", "rec_detail_type", "rec_data", "remark" },
				whereStr, null, null, null, " rec_date desc ", null);
		SimpleAdapter simpleAdapter = createSimpleAdapter(cursor);
		cursor.close();
		return simpleAdapter;
	}

	private SimpleAdapter createSimpleAdapter(Cursor cursor) {
		int i = 1;
		BigDecimal bigDec = new BigDecimal(0);
		// ���б������ֵ
		List<Map<String, Object>> listItems = new ArrayList<Map<String, Object>>();
		while (cursor.moveToNext()) {
			Map<String, Object> listItem = new HashMap<String, Object>();
			listItem.put("sequence", i++);
			listItem.put("date", cursor.getString(0).substring(2));
			listItem.put("firstType", cursor.getString(1));
			listItem.put("secoType", cursor.getString(2));
			listItem.put("num", cursor.getDouble(3));
			bigDec=bigDec.add(new BigDecimal(cursor.getDouble(3)));
			listItem.put("remark", cursor.getString(4));
			listItems.add(listItem);

		}
		accountSum = MathUtils.formatDouble(bigDec.doubleValue());

		// ����һ��SimpleAdapter
		return new SimpleAdapter(context, listItems, R.layout.rece_simple_item,
				new String[] { "sequence", "date", "firstType", "secoType",
						"num", "remark" }, new int[] { R.id.rece_list_sequence,
						R.id.rece_list_date, R.id.rece_list_first_type,
						R.id.rece_list_seco_type, R.id.rece_list_num,
						R.id.rece_list_remark });
	}

	public double getAccountSum() {
		return accountSum;
	}

	public void setAccountSum(double accountSum) {
		this.accountSum = accountSum;
	}

	public void setDbHelper(MyDatabaseHelper dbHelper) {
		this.dbHelper = dbHelper;
	}

	public MyDatabaseHelper getDbHelper() {
		return dbHelper;
	}

}
