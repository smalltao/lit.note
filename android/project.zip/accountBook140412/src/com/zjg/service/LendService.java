package com.zjg.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.SimpleAdapter;

import com.zjg.activity.R;
import com.zjg.db.ManagerDB;
import com.zjg.db.MyDatabaseHelper;
import com.zjg.model.LendRecord;
import com.zjg.util.MathUtils;
import com.zjg.util.RelativeInfo;

/**
 * Description: project start date 2014/2/17<br/>
 * Date:2014/3/4
 * 
 * @author zhaoJianGuo 1527370012@qq.com
 * @version 1.0
 */
public class LendService {
	private Context context;

	private MyDatabaseHelper dbHelper;
	private SQLiteDatabase dbConn;

	private double accountSum = 0;

	public LendService(Context context) {
		setDbHelper(ManagerDB.getDBHelper(context));
		this.context = context;
	}

	public boolean addLend(LendRecord lendRecord) {
		boolean addFlag = false;

		ContentValues values = new ContentValues();

		values.put("lend_or_borrow", lendRecord.isLendOrBorrow());
		values.put("lend_data", lendRecord.getLendNum());
		values.put("relate_person", lendRecord.getLendWho());
		values.put("lend_date", lendRecord.getLendDate());
		values.put("lend_register_date", RelativeInfo.getNowDate());
		values.put("has_refunded", false);
		values.put("remark", lendRecord.getLendRemark());
		values.put("ref_user_tab_id", RelativeInfo.userID);

		// ������ر��ļ�¼
		String updateAccont1 = null;
		String updateAccont2 = null;
		// �����ǽ��뻹�ǽ��
		if (lendRecord.isLendOrBorrow()) {
			updateAccont1 = "update account_tab set account_data=account_data+"
					+ lendRecord.getLendNum()
					+ "  where account_name=='lendSum' and ref_user_tab_id=="
					+ RelativeInfo.userID;
			updateAccont2 = "update account_tab set account_data=account_data+"
					+ 1
					+ "  where account_name=='lendNum' and ref_user_tab_id=="
					+ RelativeInfo.userID;
		} else {
			updateAccont1 = "update account_tab set account_data=account_data+"
					+ lendRecord.getLendNum()
					+ "  where account_name=='borrowSum' and ref_user_tab_id=="
					+ RelativeInfo.userID;
			updateAccont2 = "update account_tab set account_data=account_data+"
					+ 1
					+ "  where account_name=='borrowNum' and ref_user_tab_id=="
					+ RelativeInfo.userID;
		}

		dbConn = ManagerDB.getDBConn(dbHelper);

		dbConn.beginTransaction();
		try {
			dbConn.insert("lend_tab", null, values);
			dbConn.execSQL(updateAccont1);
			dbConn.execSQL(updateAccont2);

			dbConn.setTransactionSuccessful();
			addFlag = true;
		} finally {
			dbConn.endTransaction();
		}

		return addFlag;
	}

	public boolean refund(LendRecord lendRecord, double refundCount) {
		boolean addFlag = false;

		ContentValues values = new ContentValues();

		values.put("lend_or_borrow", lendRecord.isLendOrBorrow());
		values.put("relate_person", lendRecord.getLendWho());
		values.put("refund_data", refundCount);
		values.put("refund_date", RelativeInfo.getNowDate());
		values.put("refund_register_date", RelativeInfo.getNowDate());
		values.put("remark", lendRecord.getLendRemark());
		values.put("ref_user_tab_id", RelativeInfo.userID);
		values.put("ref_lend_tab_id", lendRecord.getId());

		// ������ر��ļ�¼
		// �����ܼ�¼����¼
		String updateAccont1 = null;
		String updateAccont2 = null;
		// ���½�����¼
		String updateLendTab = null;
		// ��������Ŀ
		int dealNum;
		// ����Ӧ��ȥ�Ĵ����Ľ����Ŀ
		// �����Ƿ�ȫ������
		if (lendRecord.getLendNum() == lendRecord.getHasRefundedNum()
				+ refundCount) {
			dealNum = 1;
			updateLendTab = "update lend_tab set has_refunded_data=has_refunded_data+"
					+ refundCount
					+ " , has_refunded="
					+ 1
					+ "  where _id=="
					+ lendRecord.getId();
		} else {
			dealNum = 0;
			updateLendTab = "update lend_tab set has_refunded_data=has_refunded_data+"
					+ refundCount + "  where _id==" + lendRecord.getId();
		}
		// �����ǽ��뻹�ǽ��
		if (lendRecord.isLendOrBorrow()) {
			updateAccont1 = "update account_tab set account_data=account_data-"
					+ refundCount
					+ "  where account_name=='lendSum' and ref_user_tab_id=="
					+ RelativeInfo.userID;

			updateAccont2 = "update account_tab set account_data=account_data-"
					+ dealNum
					+ "  where account_name=='lendNum' and ref_user_tab_id=="
					+ RelativeInfo.userID;
		} else {
			updateAccont1 = "update account_tab set account_data=account_data-"
					+ refundCount
					+ "  where account_name=='borrowSum' and ref_user_tab_id=="
					+ RelativeInfo.userID;
			updateAccont2 = "update account_tab set account_data=account_data-"
					+ dealNum
					+ "  where account_name=='borrowNum' and ref_user_tab_id=="
					+ RelativeInfo.userID;
		}

		dbConn = ManagerDB.getDBConn(dbHelper);

		dbConn.beginTransaction();
		try {
			dbConn.insert("refund_tab", null, values);
			dbConn.execSQL(updateAccont1);
			dbConn.execSQL(updateAccont2);
			dbConn.execSQL(updateLendTab);

			dbConn.setTransactionSuccessful();
			addFlag = true;
		} finally {
			dbConn.endTransaction();
		}

		return addFlag;
	}

	public LendRecord queryById(int id) {
		LendRecord lendRecord = new LendRecord();
		dbConn = ManagerDB.getDBConn(dbHelper);

		Cursor cursor = dbConn.query("lend_tab", new String[] { "_id",
				"lend_or_borrow", "lend_date", "relate_person", "lend_data",
				"has_refunded_data", "has_refunded", "remark" },
				"  _id==" + id, null, null, null, null, null);
		if (cursor.getCount() == 1) {
			cursor.moveToFirst();
			lendRecord.setId(cursor.getInt(0));
			lendRecord.setLendOrBorrow(cursor.getInt(1) == 1 ? true : false);
			lendRecord.setLendDate(cursor.getString(2));
			lendRecord.setLendWho(cursor.getString(3));
			lendRecord.setLendNum(cursor.getDouble(4));
			lendRecord.setHasRefundedNum(cursor.getDouble(5));
			lendRecord.setHasRefunded(cursor.getInt(6) == 1 ? true : false);
			lendRecord.setLendRemark(cursor.getString(7));
		}

		cursor.close();

		return lendRecord;
	}

	// ��ѯ����¼
	public SimpleAdapter queryLend(String queryStartDate, String queryEndDate,
			boolean lendOrBorrow) {
		SimpleAdapter simpleAdapter = null;

		dbConn = ManagerDB.getDBConn(dbHelper);

		String whereStr = " ref_user_tab_id==" + RelativeInfo.userID
				+ " and lend_date>='" + queryStartDate + "' and lend_date<='"
				+ queryEndDate + "' ";
		String wherePart;
		if (lendOrBorrow) {
			wherePart = " and lend_or_borrow==" + 1 + " ";
		} else {
			wherePart = " and lend_or_borrow==" + 0 + " ";
		}
		whereStr += wherePart;

		Cursor cursor = dbConn.query("lend_tab", new String[] { "_id",
				"lend_or_borrow", "lend_date", "relate_person", "lend_data",
				"remark" }, whereStr, null, null, null, " lend_date desc ",
				null);
		simpleAdapter = createSimpleAdapter(cursor);
		cursor.close();

		return simpleAdapter;
	}

	private SimpleAdapter createSimpleAdapter(Cursor cursor) {
		int i = 1;
		BigDecimal bigDec = new BigDecimal(0);
		// ���б������ֵ
		List<Map<String, Object>> listItems = new ArrayList<Map<String, Object>>();
		while (cursor.moveToNext()) {
			Map<String, Object> listItem = new HashMap<String, Object>();
			listItem.put("id", cursor.getInt(0));
			listItem.put("sequence", i++);
			listItem.put("date", cursor.getString(2).substring(2));
			listItem.put("lendWho", cursor.getString(3));
			listItem.put("num", cursor.getDouble(4));
			listItem.put("remark", cursor.getString(5));
			listItems.add(listItem);
			bigDec=bigDec.add(new BigDecimal(cursor.getDouble(4)));
		}
		accountSum = MathUtils.formatDouble(bigDec.doubleValue());

		// ����һ��SimpleAdapter
		return new SimpleAdapter(context, listItems, R.layout.lend_simple_item,
				new String[] { "id", "sequence", "date", "lendWho", "num",
						"remark" }, new int[] { R.id.lend_list_id,
						R.id.lend_list_sequence, R.id.lend_list_date,
						R.id.lend_list_name, R.id.lend_list_num,
						R.id.lend_list_remark });
	}

	public void setDbHelper(MyDatabaseHelper dbHelper) {
		this.dbHelper = dbHelper;
	}

	public MyDatabaseHelper getDbHelper() {
		return dbHelper;
	}

	public SQLiteDatabase getDbConn() {
		return dbConn;
	}

	public void setDbConn(SQLiteDatabase dbConn) {
		this.dbConn = dbConn;
	}

	public double getAccountSum() {
		return accountSum;
	}

	public void setAccountSum(double accountSum) {
		this.accountSum = accountSum;
	}

}
