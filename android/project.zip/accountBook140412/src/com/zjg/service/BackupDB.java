package com.zjg.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import android.content.Context;
import android.os.Handler;

public class BackupDB {
	private final static String SDCARD_PATH = File.separator + "mnt"
			+ File.separator + "sdcard";
	private final static String DB_PATH = File.separator + "accountBook"
			+ File.separator + "account_book.db3";
	private File sdCardFile = new File(SDCARD_PATH);
	private File dbFile = new File(SDCARD_PATH + DB_PATH);

	private Handler handler;

	private long fileSize = 0;
	public static long progress = 0;

	public BackupDB(Context context, Handler hander) {
		this.handler = hander;

		//��ʼ���ļ���С
		if (sdCardFile.exists()) {

			if (dbFile.exists()) {
				// �ļ��Ƿ���������С
				if (dbFile.length() % 1024 == 0) {
					fileSize = dbFile.length() / 1024;
				} else {
					fileSize = dbFile.length() / 1024 + 1;
				}

			}
		}
	}

	public int backupDBData() {
		int flag = 0;

		if (sdCardFile.exists()) {

			if (dbFile.exists()) {
				
				if (read(SDCARD_PATH + DB_PATH, SDCARD_PATH + File.separator
						+ "account_book.db3")) {
					flag = 1;
				} else {
					// ����ʱ�����쳣
					flag = -3;
				}
			} else {
				// �����������ļ�
				flag = -2;
			}
		} else {
			// ������SDCARD������-1
			flag = -1;
		}

		return flag;
	}

	private boolean read(String sourceFile, String dircetFile) {
		boolean flag = false;

		// ���ļ�������
		FileInputStream fis = null;
		FileOutputStream fos = null;
		try {
			// ���ļ�������
			fis = new FileInputStream(new File(sourceFile));
			fos = new FileOutputStream(new File(dircetFile));

			byte[] buff = new byte[1024];

			// ��ȡ�ļ�����
			while (fis.read(buff) > 0) {
				progress++;
				handler.sendEmptyMessage(0x123);
				fos.write(buff);
			}
			// �ر��ļ�������
			flag = true;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (fis != null) {
				try {
					fis.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (fos != null) {
				try {
					fos.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return flag;
	}

	public long getFileSize() {
		return fileSize;
	}

	public void setFileSize(long fileSize) {
		this.fileSize = fileSize;
	}

	
	
}
