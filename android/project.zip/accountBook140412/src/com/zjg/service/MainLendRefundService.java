package com.zjg.service;

import android.content.Context;
import android.database.Cursor;

import com.zjg.db.ManagerDB;
import com.zjg.db.MyDatabaseHelper;
import com.zjg.util.MathUtils;


/**
 * Description: project start date 2014/2/17<br/>
 * Date:2014/2/25
 * 
 * @author zhaoJianGuo 1527370012@qq.com
 * @version 1.0
 */
public class MainLendRefundService {
   
	private MyDatabaseHelper dbHelper;
	private Cursor serCursor;
	
	public MainLendRefundService(Context context){
		setDbHelper(ManagerDB.getDBHelper(context));
		
    }

	
	/**
	 * 
	 * @return �����ĩ���Ŀ�����Ŀ
	 */
	public int getLendNum(int userID){
		serCursor=dbHelper.getReadableDatabase().query("account_tab", new
				  String[]{"_id","account_data"}, "account_name=='lendNum' and ref_user_tab_id=="+userID+"", null, null, null, null, null);
		serCursor.moveToFirst();
		int returnInt=serCursor.getInt(1);
		serCursor.close();
		
		return returnInt;
	}
	
	/**
	 * 
	 * @return �����ĩ���Ŀ�����
	 */	
	public double getLendSum(int userID){
		serCursor=dbHelper.getReadableDatabase().query("account_tab", new
				  String[]{"_id","account_data"}, "account_name=='lendSum' and ref_user_tab_id=="+userID+"", null, null, null, null, null);
		serCursor.moveToFirst();
		double returnDouble=MathUtils.formatDouble( serCursor.getDouble(1)  );
		serCursor.close();
        
		return returnDouble;
	}
	
	/**
	 * 
	 * @return �����ĩ���Ŀ�����Ŀ
	 */
	public int getBorrowNum(int userID){
		serCursor=dbHelper.getReadableDatabase().query("account_tab", new
				  String[]{"_id","account_data"}, "account_name=='borrowNum' and ref_user_tab_id=="+userID+"", null, null, null, null, null);
		serCursor.moveToFirst();
		int returnInt=serCursor.getInt(1);
		serCursor.close();
		
		return returnInt;
	}

	/**
	 * 
	 * @return �����ĩ���Ŀ�����Ŀ
	 */
	public double getBorrowSum(int userID){
		serCursor=dbHelper.getReadableDatabase().query("account_tab", new
				  String[]{"_id","account_data"}, "account_name=='borrowSum' and ref_user_tab_id=="+userID+"", null, null, null, null, null);
		serCursor.moveToFirst();
		double returnDouble=MathUtils.formatDouble(  serCursor.getDouble(1)  );
		serCursor.close();
		
		return returnDouble;
	}
	
	public void setDbHelper(MyDatabaseHelper dbHelper) {
		this.dbHelper = dbHelper;
	}

	public MyDatabaseHelper getDbHelper() {
		return dbHelper;
	}
	
	
}
